/* features.js - เพิ่มฟีเจอร์: จำนวนสินค้าที่ขาย, กราฟขายต่อวัน, สรุปรายปี
   วางไว้โฟลเดอร์เดียวกับ index.html แล้วเพิ่ม <script src="features.js"></script> ก่อน </body> */
(function () {
  'use strict';
  var TH_M = ['ม.ค.','ก.พ.','มี.ค.','เม.ย.','พ.ค.','มิ.ย.','ก.ค.','ส.ค.','ก.ย.','ต.ค.','พ.ย.','ธ.ค.'];
  function $(id) { return document.getElementById(id); }
  function num(n) { return Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 }); }

  /* แสดงปีเป็น ค.ศ. (เช่น พฤศจิกายน 2026) */
  window.formatThaiMonth = function (monthStr) {
    var p = monthStr.split('-');
    var m = ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
    return m[parseInt(p[1], 10) - 1] + ' ' + parseInt(p[0], 10);
  };

  /* ---------- 1) ช่องกรอกจำนวนสินค้า ---------- */
  function injectField(selectId, groupId, inputId) {
    var sel = $(selectId);
    if (!sel || $(groupId)) return;
    sel.closest('.form-group').insertAdjacentHTML('beforebegin',
      '<div class="form-group" id="' + groupId + '" style="display:none">' +
      '<label class="form-label">จำนวนที่ขายได้ (ชิ้น/ก้อน)</label>' +
      '<input type="number" id="' + inputId + '" class="input-field" placeholder="เช่น 5" inputmode="decimal" min="0" step="any"></div>');
  }
  injectField('qe-account', 'qe-qty-group', 'qe-qty');
  injectField('tx-account-select', 'tx-qty-group', 'tx-qty');

  /* ช่องชื่อผู้จ่ายเงิน (รายรับ) / ผู้รับเงิน (รายจ่าย) วางก่อนช่องโน้ต */
  function injectParty(noteId, groupId, inputId) {
    var note = $(noteId);
    if (!note || $(groupId)) return;
    note.closest('.form-group').insertAdjacentHTML('beforebegin',
      '<div class="form-group" id="' + groupId + '">' +
      '<label class="form-label" id="' + groupId + '-label">ผู้รับเงิน</label>' +
      '<input type="text" id="' + inputId + '" class="input-field" list="mt-parties" autocomplete="off" placeholder="เช่น ชื่อร้านค้า" maxlength="80"></div>');
  }
  injectParty('qe-note', 'qe-party-group', 'qe-party');
  injectParty('tx-note', 'tx-party-group', 'tx-party');

  /* รายชื่อที่เคยใช้ (เลือกจากรายการ หรือพิมพ์ชื่อใหม่ได้) */
  function refreshParties() {
    var dl = $('mt-parties');
    if (!dl) { dl = document.createElement('datalist'); dl.id = 'mt-parties'; document.body.appendChild(dl); }
    var seen = {}, names = [];
    (appState.parties || []).concat((appState.transactions || []).map(function (t) { return t.party; })).forEach(function (n) {
      n = String(n || '').trim();
      if (n && !seen[n]) { seen[n] = 1; names.push(n); }
    });
    dl.innerHTML = '';
    names.slice(0, 200).forEach(function (n) { var o = document.createElement('option'); o.value = n; dl.appendChild(o); });
  }

  function setPartyLabel(groupId, inputId, type) {
    var l = $(groupId + '-label'), i = $(inputId);
    if (!l || !i) return;
    var inc = type === 'Income';
    l.textContent = inc ? 'ผู้จ่ายเงิน (ใครจ่ายเงินให้เรา)' : 'ผู้รับเงิน (เราจ่ายเงินให้ใคร)';
    i.placeholder = inc ? 'เช่น ชื่อลูกค้า' : 'เช่น ชื่อร้านค้า';
  }

  var _oqe = window.openQuickEntry;
  window.openQuickEntry = function (type) {
    _oqe(type);
    $('qe-qty-group').style.display = (type === 'Income') ? 'block' : 'none';
    $('qe-qty').value = '';
    $('qe-party').value = '';
    setPartyLabel('qe-party-group', 'qe-party', type);
  };

  var _stt = window.setTxType;
  window.setTxType = function (t) {
    _stt(t);
    var g = $('tx-qty-group');
    if (g) g.style.display = (t === 'Income') ? 'block' : 'none';
    setPartyLabel('tx-party-group', 'tx-party', t);
  };

  var _oatm = window.openAddTransactionModal;
  window.openAddTransactionModal = function (p) { _oatm(p); $('tx-qty').value = ''; $('tx-party').value = ''; };

  var _oetm = window.openEditTransactionModal;
  window.openEditTransactionModal = function (tx) {
    _oetm(tx);
    $('tx-qty').value = tx.quantity > 0 ? tx.quantity : '';
    $('tx-party').value = tx.party || '';
  };

  /* ---------- 2) ความเร็ว: บันทึกทันที + โหลดครั้งเดียว + จำข้อมูลล่าสุด ---------- */
  var pending = 0, booted = false;

  function uid() {
    try { if (window.crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (e) {}
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      var r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16);
    });
  }
  function saveLocal(month, b) { try { localStorage.setItem('mt_boot_v2', JSON.stringify({ month: month, bundle: b })); } catch (e) {} }
  function readLocal(month) {
    try { var o = JSON.parse(localStorage.getItem('mt_boot_v2') || 'null'); return o && o.month === month ? o.bundle : null; } catch (e) { return null; }
  }
  function bundleFromState() {
    return {
      profile: appState.profile, accounts: appState.accounts, categories: appState.categories,
      currency: CURRENCY, budget: appState.budget, summary: appState.summary,
      recentSpending: appState.recentSpending, recentIncome: appState.recentIncome,
      transactions: appState.transactions
    };
  }
  function applyBundle(month, r) {
    if (!appState.monthCache[month]) appState.monthCache[month] = {};
    appState.monthCache[month].dashboard = r;
    appState.monthCache[month].transactions = r.transactions || [];
    if (r.parties) appState.parties = r.parties;
    refreshParties();
    if (month === appState.selectedMonth) {
      appState.profile = r.profile; appState.accounts = r.accounts; appState.categories = r.categories;
      appState.budget = r.budget; appState.summary = r.summary;
      appState.recentSpending = r.recentSpending; appState.recentIncome = r.recentIncome || [];
      appState.transactions = r.transactions || [];
    }
  }

  /* วิธีเดิม (2 คำสั่ง) ใช้เป็นตัวสำรองถ้า getMonthBundle ใช้ไม่ได้ */
  function legacyFetch(monthStr, callback) {
    google.script.run
      .withSuccessHandler(function (r) {
        if (!appState.monthCache[monthStr]) appState.monthCache[monthStr] = {};
        appState.monthCache[monthStr].dashboard = r;
        google.script.run
          .withSuccessHandler(function (txs) {
            r.transactions = txs;
            applyBundle(monthStr, r);
            saveLocal(monthStr, r);
            if (callback) callback(r);
          })
          .withFailureHandler(function () { r.transactions = []; applyBundle(monthStr, r); if (callback) callback(r); })
          .getTransactionsQ(monthStr);
      })
      .withFailureHandler(function (err) { closeLoading(); showError('เกิดข้อผิดพลาดในการโหลดข้อมูล: ' + ((err && err.message) || '')); })
      .getDashboardData(monthStr);
  }

  function network(monthStr, cb, silent) {
    google.script.run
      .withSuccessHandler(function (r) {
        if (silent && pending > 0) return; // มีรายการที่กำลังบันทึกอยู่ ไม่เอาข้อมูลเก่าทับ
        applyBundle(monthStr, r);
        saveLocal(monthStr, r);
        if (cb) cb(r);
      })
      .withFailureHandler(function () { if (!silent) legacyFetch(monthStr, cb); })
      .getMonthBundle(monthStr);
  }

  window.fetchMonthData = function (monthStr, callback) {
    var cached = !booted ? readLocal(monthStr) : null;
    booted = true;
    if (cached) {
      applyBundle(monthStr, cached);
      if (callback) callback(cached);               // แสดงข้อมูลล่าสุดที่จำไว้ทันที
      network(monthStr, function () {               // แล้วอัปเดตเป็นข้อมูลจริงเบื้องหลัง
        if (appState.selectedMonth === monthStr) applyCachedMonth(monthStr);
      }, true);
      return;
    }
    network(monthStr, callback, false);
  };

  window.preloadAdjacentMonths = function () {}; // เลิกโหลดเดือนอื่นล่วงหน้า (ลดภาระ)

  /* แก้ข้อมูลในเครื่องทันที แล้วค่อยส่งไปบันทึกเบื้องหลัง */
  function effect(tx) { return tx.type === 'Income' ? tx.amount : -tx.amount; }
  function adjustAccount(id, delta) {
    (appState.accounts || []).forEach(function (a) { if (a.id === id) a.balance = (a.balance || 0) + delta; });
  }
  function adjustRecent(tx, sign) {
    var list = tx.type === 'Income' ? appState.recentIncome : appState.recentSpending;
    (list || []).forEach(function (e) { if (e.date === tx.date) e.amount += sign * tx.amount; });
  }
  function removeTx(tx) {
    adjustAccount(tx.accountId, -effect(tx));
    adjustRecent(tx, -1);
    appState.transactions = (appState.transactions || []).filter(function (t) { return t.id !== tx.id; });
  }
  function insertTx(tx) {
    adjustAccount(tx.accountId, effect(tx));
    adjustRecent(tx, 1);
    if (String(tx.date).substring(0, 7) === appState.selectedMonth) {
      appState.transactions.unshift(tx);
      appState.transactions.sort(function (a, b) { return b.date.localeCompare(a.date); });
    }
  }
  function commitLocal() {
    var inc = 0, exp = 0;
    (appState.transactions || []).forEach(function (t) {
      if (t.type === 'Income') inc += t.amount; else if (t.type === 'Expense') exp += t.amount;
    });
    var overall = (appState.budget && appState.budget.overall) || 0;
    appState.summary = { income: inc, expense: exp, balance: inc - exp };
    appState.budget = { overall: overall, used: exp, remaining: overall - exp };
    var b = bundleFromState();
    appState.monthCache = {};
    appState.monthCache[appState.selectedMonth] = { dashboard: b, transactions: appState.transactions };
    saveLocal(appState.selectedMonth, b);
    applyCachedMonth(appState.selectedMonth);
  }
  function resync() {
    appState.monthCache = {};
    network(appState.selectedMonth, function () { applyCachedMonth(appState.selectedMonth); }, false);
  }
  function bg(name, args) {
    pending++;
    var r = google.script.run
      .withSuccessHandler(function () { pending--; })
      .withFailureHandler(function (err) {
        pending--;
        showError('บันทึกไม่สำเร็จ: ' + ((err && err.message) || 'ไม่ทราบสาเหตุ') + ' (กำลังโหลดข้อมูลจริงอีกครั้ง)');
        resync();
      });
    r[name].apply(r, args);
  }

  function saveNow(tx, oldId) {
    tx.id = oldId || uid();
    tx.amount = Number(tx.amount);
    tx.createdAt = new Date().toISOString();
    if (oldId) {
      var old = (appState.transactions || []).filter(function (t) { return t.id === oldId; })[0];
      if (old) { tx.createdAt = old.createdAt; removeTx(old); }
    }
    insertTx(tx);
    if (tx.party && (appState.parties || (appState.parties = [])).indexOf(tx.party) === -1) appState.parties.unshift(tx.party);
    refreshParties();
    commitLocal();
    if (oldId) bg('editTxLean', [oldId, tx]); else bg('addTxLean', [tx]);
  }

  window.submitQuickEntry = function () {
    var amount = parseFloat($('qe-amount').value);
    var categoryId = $('qe-category').value;
    var accountId = $('qe-account').value;
    var note = $('qe-note').value;
    var dateStr = $('qe-date').value;
    var qty = quickEntryType === 'Income' ? (parseFloat($('qe-qty').value) || 0) : 0;

    if (!amount || amount <= 0) { showError('กรุณากรอกจำนวนเงิน'); return; }
    if (!dateStr) { showError('กรุณาเลือกวันที่'); return; }
    if (!categoryId) { showError('ยังไม่มีหมวดหมู่ประเภทนี้ ไปเพิ่มได้ที่ ข้อมูลฉัน → จัดการหมวดหมู่'); return; }
    if (!accountId) { showError('ยังไม่มีบัญชีการเงิน ไปเพิ่มได้ที่ ตั้งค่า → บัญชี'); return; }

    saveNow({ amount: amount, date: dateStr, type: quickEntryType, categoryId: categoryId, accountId: accountId, note: note, quantity: qty, party: $('qe-party').value.trim() }, null);
    closeQuickEntry();
    showSuccess('บันทึกสำเร็จ!');
  };

  window.submitTransaction = function () {
    var id = $('tx-id').value;
    var amount = parseFloat($('tx-amount').value);
    var date = $('tx-date').value;
    var note = $('tx-note').value;
    var accountId = $('tx-account-select').value;
    var qty = appState.currentTxType === 'Income' ? (parseFloat($('tx-qty').value) || 0) : 0;

    if (!amount || amount <= 0 || !date || !appState.selectedCategoryId) {
      showError('กรุณากรอกข้อมูลจำนวนเงิน วันที่ และเลือกหมวดหมู่ให้ครบถ้วน'); return;
    }
    saveNow({ amount: amount, date: date, type: appState.currentTxType, categoryId: appState.selectedCategoryId, accountId: accountId, note: note, quantity: qty, party: $('tx-party').value.trim() }, id || null);
    closeModal('modal-transaction');
    showSuccess(id ? 'แก้ไขรายการสำเร็จ!' : 'เพิ่มรายการสำเร็จ!');
  };

  window.deleteCurrentTransaction = function () {
    var id = $('tx-id').value;
    if (!id) return;
    Swal.fire({
      title: 'ยืนยันลบรายการ?', text: 'คุณต้องการลบรายการธุรกรรมนี้ใช่หรือไม่?', icon: 'warning',
      showCancelButton: true, confirmButtonColor: '#f49ca3', cancelButtonColor: '#9cd5f4',
      confirmButtonText: 'ยืนยันลบ', cancelButtonText: 'ยกเลิก'
    }).then(function (result) {
      if (!result.isConfirmed) return;
      var tx = (appState.transactions || []).filter(function (t) { return t.id === id; })[0];
      if (tx) { removeTx(tx); commitLocal(); }
      closeModal('modal-transaction');
      showSuccess('ลบรายการสำเร็จ');
      bg('deleteTxLean', [id]);
    });
  };

  /* แสดงจำนวนในหน้ารายการ */
  var _url = window.updateRecordsList;
  window.updateRecordsList = function (txs) {
    _url(txs);
    var items = document.querySelectorAll('#records-list-container .tx-item');
    (txs || []).forEach(function (tx, i) {
      var n = items[i] && items[i].querySelector('.tx-note');
      if (!n) return;
      if (tx.party) n.textContent = (tx.type === 'Income' ? 'จาก ' : 'ถึง ') + tx.party + ' · ' + n.textContent;
      if (tx.type === 'Income' && tx.quantity > 0) n.textContent = n.textContent + ' · ขาย ' + num(tx.quantity) + ' ชิ้น';
    });
  };

  window.filterRecords = function () {
    var q = $('records-search').value.toLowerCase();
    var list = (appState.transactions || []).filter(function (tx) {
      var cat = getCategoryById(tx.categoryId);
      var hay = ((cat ? cat.name : '') + ' ' + (tx.note || '') + ' ' + (tx.party || '')).toLowerCase();
      return hay.indexOf(q) !== -1;
    });
    window.updateRecordsList(list);
  };

  /* ---------- 4) กราฟ ---------- */
  var fxDaily = null, fxYearChart = null, fxYear = null, fxYearCache = {};

  var repCache = {};
  var _ss = window.showSuccess;
  window.showSuccess = function (m) { fxYearCache = {}; repCache = {}; _ss(m); };

  var H3 = 'font-size:14px;font-weight:800;margin-bottom:12px;display:flex;align-items:center;gap:8px;';
  function injectCards() {
    if ($('fx-daily-card')) return;
    $('view-charts').insertAdjacentHTML('beforeend',
      '<div class="card" id="fx-prod-card" style="display:none">' +
        '<h3 style="' + H3 + '"><i class="fa-solid fa-cake-candles" style="color:var(--income-hover)"></i><span>ยอดขายแยกตามสินค้า</span></h3>' +
        '<div id="fx-prod-list"></div></div>' +
      '<div class="card" id="fx-daily-card" style="display:none">' +
        '<h3 style="' + H3 + '"><i class="fa-solid fa-chart-column" style="color:var(--income-hover)"></i><span>จำนวนที่ขายได้ต่อวัน</span></h3>' +
        '<p id="fx-daily-empty" style="display:none;text-align:center;color:var(--text-light);font-size:13px;">ยังไม่มีข้อมูลจำนวนสินค้าในเดือนนี้</p>' +
        '<div id="fx-daily-wrap" style="height:230px;position:relative"><canvas id="fx-daily-canvas"></canvas></div></div>' +
      '<div class="card" id="fx-year-card">' +
        '<h3 style="' + H3 + '"><i class="fa-solid fa-calendar-days" style="color:var(--primary-hover)"></i><span>สรุปรายรับ-รายจ่ายรายปี</span></h3>' +
        '<div class="month-selector-bar" style="box-shadow:none;margin-bottom:12px">' +
          '<button class="btn-arrow" onclick="fxShiftYear(-1)"><i class="fa-solid fa-chevron-left"></i></button>' +
          '<span id="fx-year-title" class="month-title">ปี</span>' +
          '<button class="btn-arrow" onclick="fxShiftYear(1)"><i class="fa-solid fa-chevron-right"></i></button></div>' +
        '<p id="fx-year-status" style="text-align:center;color:var(--text-light);font-size:12px"></p>' +
        '<div id="fx-year-totals" style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px"></div>' +
        '<div style="height:230px;position:relative"><canvas id="fx-year-canvas"></canvas></div>' +
        '<h4 style="font-size:13px;font-weight:800;margin:16px 0 8px">สินค้าขายดีประจำปี</h4>' +
        '<div id="fx-year-products"></div></div>');
  }

  function iconBox(cat) {
    return '<div style="background:' + cat.color + ';width:32px;height:32px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0">' +
      renderCategoryIcon(cat.icon, 'var(--text)', '15px') + '</div>';
  }
  function productRows(entries) {
    if (!entries.length) return '<p style="text-align:center;color:var(--text-light);font-size:13px;">ยังไม่มีข้อมูล</p>';
    return entries.map(function (e) {
      var c = getCategoryById(e.id) || { name: 'อื่นๆ', icon: 'other', color: '#ECEFF1' };
      return '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">' + iconBox(c) +
        '<div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:700">' + c.name + '</div>' +
        '<div style="font-size:11px;color:var(--text-light)">' + (e.qty > 0 ? 'ขายได้ ' + num(e.qty) + ' ชิ้น' : 'ไม่ได้ระบุจำนวน') + '</div></div>' +
        '<div style="font-weight:800;font-size:13px;color:var(--income-hover)">' + fmtMoney(e.amt) + '</div></div>';
    }).join('');
  }

  function renderProducts() {
    var isInc = appState.chartsType === 'Income';
    $('fx-prod-card').style.display = isInc ? 'block' : 'none';
    $('fx-daily-card').style.display = isInc ? 'block' : 'none';
    if (!isInc) { if (fxDaily) { fxDaily.destroy(); fxDaily = null; } return; }

    var parts = appState.selectedMonth.split('-');
    var days = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10), 0).getDate();
    var by = {};
    (appState.transactions || []).filter(function (t) { return t.type === 'Income'; }).forEach(function (t) {
      var o = by[t.categoryId] || (by[t.categoryId] = { id: t.categoryId, qty: 0, amt: 0, daily: new Array(days).fill(0) });
      var q = t.quantity || 0;
      o.qty += q; o.amt += t.amount;
      var d = parseInt(String(t.date).substring(8, 10), 10);
      if (d >= 1 && d <= days) o.daily[d - 1] += q;
    });
    var list = Object.keys(by).map(function (k) { return by[k]; }).sort(function (a, b) { return b.amt - a.amt; });
    $('fx-prod-list').innerHTML = productRows(list);

    var ds = list.filter(function (e) { return e.qty > 0; }).map(function (e) {
      var c = getCategoryById(e.id) || { name: 'อื่นๆ', color: '#ECEFF1' };
      return { label: c.name, data: e.daily, backgroundColor: c.color, borderColor: 'rgba(0,0,0,.18)', borderWidth: 1, borderRadius: 3 };
    });
    $('fx-daily-empty').style.display = ds.length ? 'none' : 'block';
    $('fx-daily-wrap').style.display = ds.length ? 'block' : 'none';
    if (fxDaily) { fxDaily.destroy(); fxDaily = null; }
    if (!ds.length) return;
    var labels = []; for (var i = 1; i <= days; i++) labels.push(String(i));
    fxDaily = new Chart($('fx-daily-canvas').getContext('2d'), {
      type: 'bar', data: { labels: labels, datasets: ds },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom', labels: { font: { family: 'Prompt', size: 11 }, boxWidth: 12 } },
          tooltip: { callbacks: { label: function (c) { return ' ' + c.dataset.label + ': ' + num(c.parsed.y) + ' ' + (window.mtT ? mtT('ชิ้น') : 'ชิ้น'); } } }
        },
        scales: {
          x: { stacked: true, grid: { display: false }, ticks: { font: { size: 10 } }, title: { display: true, text: (window.mtT ? mtT('วันที่') : 'วันที่'), font: { size: 10 } } },
          y: { stacked: true, beginAtZero: true, ticks: { precision: 0, font: { size: 10 } } }
        }
      }
    });
  }

  window.fxShiftYear = function (d) { fxYear += d; loadYear(); };

  function loadYear() {
    if (fxYear === null) fxYear = parseInt(appState.selectedMonth.substring(0, 4), 10);
    $('fx-year-title').textContent = 'ปี ' + fxYear;
    if (fxYearCache[fxYear]) { renderYear(fxYearCache[fxYear]); return; }
    $('fx-year-status').textContent = 'กำลังโหลด...';
    var y = fxYear;
    google.script.run
      .withSuccessHandler(function (res) { fxYearCache[y] = res; if (y === fxYear) renderYear(res); })
      .withFailureHandler(function (e) { $('fx-year-status').textContent = 'โหลดไม่สำเร็จ: ' + ((e && e.message) || ''); })
      .getYearSummary(y);
  }

  function renderYear(res) {
    $('fx-year-status').textContent = '';
    var profit = res.totalIncome - res.totalExpense;
    function box(label, val, color) {
      return '<div style="background:var(--bg);border-radius:14px;padding:10px 6px;text-align:center">' +
        '<div style="font-size:10px;color:var(--text-light);font-weight:700">' + label + '</div>' +
        '<div style="font-size:12px;font-weight:800;color:' + color + ';margin-top:2px">' + fmtMoney(val) + '</div></div>';
    }
    $('fx-year-totals').innerHTML = box('รายรับรวม', res.totalIncome, 'var(--income-hover)') +
      box('รายจ่ายรวม', res.totalExpense, 'var(--expense-hover)') + box('คงเหลือ', profit, 'var(--primary-hover)');

    if (fxYearChart) fxYearChart.destroy();
    fxYearChart = new Chart($('fx-year-canvas').getContext('2d'), {
      type: 'bar',
      data: {
        labels: TH_M.map(function (m) { return window.mtT ? mtT(m) : m; }),
        datasets: [
          { label: 'รายรับ', data: res.months.map(function (m) { return m.income; }), backgroundColor: 'rgba(154,215,168,.8)', borderColor: 'rgba(129,199,132,1)', borderWidth: 1.5, borderRadius: 5 },
          { label: 'รายจ่าย', data: res.months.map(function (m) { return m.expense; }), backgroundColor: 'rgba(244,156,163,.8)', borderColor: 'rgba(229,115,115,1)', borderWidth: 1.5, borderRadius: 5 }
        ]
      },
      options: {
        responsive: true, maintainAspectRatio: false,
        plugins: {
          legend: { position: 'bottom', labels: { font: { family: 'Prompt', size: 11 }, boxWidth: 12 } },
          tooltip: { callbacks: { label: function (c) { return ' ' + c.dataset.label + ': ' + fmtMoney(c.parsed.y); } } }
        },
        scales: {
          x: { grid: { display: false }, ticks: { font: { size: 9 } } },
          y: { beginAtZero: true, ticks: { font: { size: 10 }, callback: function (v) { return compactMoney(v); } } }
        }
      }
    });

    var entries = Object.keys(res.products || {}).map(function (k) {
      return { id: k, qty: res.products[k].quantity, amt: res.products[k].income };
    }).sort(function (a, b) { return b.amt - a.amt; });
    $('fx-year-products').innerHTML = productRows(entries);
  }

  /* ---------- 5) รายงานตามชื่อ: รายวัน / รายเดือน / รายปี ---------- */
  var repMode = 'month';
  function esc(t) { return String(t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }

  function injectReport() {
    if ($('fx-rep-card')) return;
    $('view-charts').insertAdjacentHTML('beforeend',
      '<div class="card" id="fx-rep-card">' +
        '<h3 style="' + H3 + '"><i class="fa-solid fa-user-group" style="color:var(--primary-hover)"></i><span>รายงานตามชื่อผู้จ่าย / ผู้รับเงิน</span></h3>' +
        '<div class="segmented-control">' +
          '<button class="segment-btn" id="fx-rep-day" onclick="fxRepSet(\'day\')">รายวัน</button>' +
          '<button class="segment-btn" id="fx-rep-month" onclick="fxRepSet(\'month\')">รายเดือน</button>' +
          '<button class="segment-btn" id="fx-rep-year" onclick="fxRepSet(\'year\')">รายปี</button></div>' +
        '<input type="date" id="fx-rep-date" class="input-field" style="display:none;margin-bottom:10px" onchange="fxRepLoad()">' +
        '<p id="fx-rep-label" style="text-align:center;font-weight:800;font-size:13px;margin-bottom:10px"></p>' +
        '<div id="fx-rep-totals" style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-bottom:12px"></div>' +
        '<div id="fx-rep-list"></div></div>');
    $('fx-rep-date').value = todayStr();
  }

  function repKey() {
    if (repMode === 'day') return $('fx-rep-date').value || todayStr();
    if (repMode === 'month') return appState.selectedMonth;
    return String(fxYear || appState.selectedMonth.substring(0, 4));
  }

  window.fxRepSet = function (m) { repMode = m; window.fxRepLoad(); };

  window.fxRepLoad = function () {
    if (!$('fx-rep-card')) return;
    ['day', 'month', 'year'].forEach(function (k) {
      var b = $('fx-rep-' + k), on = k === repMode;
      b.style.background = on ? 'var(--primary)' : 'transparent';
      b.style.color = on ? '#fff' : '';
    });
    $('fx-rep-date').style.display = repMode === 'day' ? 'block' : 'none';
    var key = repKey(), ck = repMode + '|' + key;
    $('fx-rep-label').textContent = repMode === 'day' ? key : (repMode === 'month' ? formatThaiMonth(key) : 'ปี ' + key);
    if (repCache[ck]) { renderRep(repCache[ck]); return; }
    $('fx-rep-list').innerHTML = '<p style="text-align:center;color:var(--text-light);font-size:12px">กำลังโหลด...</p>';
    google.script.run
      .withSuccessHandler(function (res) { repCache[ck] = res; if (ck === repMode + '|' + repKey()) renderRep(res); })
      .withFailureHandler(function (e) { $('fx-rep-list').innerHTML = '<p style="text-align:center;color:var(--text-light);font-size:12px">โหลดไม่สำเร็จ: ' + esc((e && e.message) || '') + '</p>'; })
      .getPartyReport(repMode, key);
  };

  function renderRep(res) {
    function box(label, val, color) {
      return '<div style="background:var(--bg);border-radius:14px;padding:10px 6px;text-align:center"><div style="font-size:10px;color:var(--text-light);font-weight:700">' + label +
        '</div><div style="font-size:13px;font-weight:800;color:' + color + '">' + fmtMoney(val) + '</div></div>';
    }
    $('fx-rep-totals').innerHTML = box('รายรับ', res.totalIncome, 'var(--income-hover)') + box('รายจ่าย', res.totalExpense, 'var(--expense-hover)') +
      box('คงเหลือ', res.totalIncome - res.totalExpense, 'var(--primary-hover)');
    if (!res.list.length) { $('fx-rep-list').innerHTML = '<p style="text-align:center;color:var(--text-light);font-size:13px">ไม่มีรายการในช่วงนี้</p>'; return; }
    $('fx-rep-list').innerHTML = res.list.map(function (e) {
      var right = (e.income ? '<div style="color:var(--income-hover)">+' + fmtMoney(e.income) + '</div>' : '') +
                  (e.expense ? '<div style="color:var(--expense-hover)">-' + fmtMoney(e.expense) + '</div>' : '');
      return '<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-top:1px solid var(--primary-light);font-size:13px;font-weight:700">' +
        '<div><div>' + (e.name ? esc(e.name) : '<span style="color:var(--text-light)">ไม่ระบุชื่อ</span>') + '</div>' +
        '<div style="font-size:11px;color:var(--text-light);font-weight:500">' + e.count + ' รายการ</div></div>' +
        '<div style="text-align:right">' + right + '</div></div>';
    }).join('');
  }

  var _uc = window.updateChartsUI;
  window.updateChartsUI = function () {
    _uc();
    injectCards();
    renderProducts();
    loadYear();
    injectReport();
    window.fxRepLoad();
  };

  injectCards();
})();
