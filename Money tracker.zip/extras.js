/* extras.js - (1) เปิดแอปเร็วขึ้น (2) ยอดคงเหลือรวมทุกบัญชี แก้ไขเองได้
   โหลดต่อท้าย features เสมอ โดย index.html */
(function () {
  'use strict';
  function $(id) { return document.getElementById(id); }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; }

  /* ---------- 0) ย้ายแถบเมนู (บน/ล่าง/ซ้าย/ขวา) ----------
     วิธีใช้: กดแถบเมนูค้างไว้ ~0.5 วินาที
       - ปล่อยนิ้วเฉยๆ  -> เปิดป๊อปอัปให้เลือกตำแหน่ง
       - ลากไปที่ขอบจอที่ต้องการ แล้วปล่อย -> แถบเมนูย้ายไปขอบนั้นเลย
     (ยังเลือกได้จาก ตั้งค่า -> ตำแหน่งแถบเมนู เหมือนเดิม) */
  var NAV_POS = ['top', 'bottom', 'left', 'right'];
  var NAV_LABEL = { top: 'บน', bottom: 'ล่าง', left: 'ซ้าย', right: 'ขวา' };
  function navPos() { var v = ls('mt_nav_pos2'); return NAV_POS.indexOf(v) >= 0 ? v : 'top'; }
  function applyNav(pos) {
    document.documentElement.setAttribute('data-nav', pos);
    document.querySelectorAll('.nav-pos-option, .fx-pop-opt').forEach(function (el) {
      el.classList.toggle('active', el.getAttribute('data-pos') === pos);
    });
  }
  window.fxSetNav = function (pos) { if (NAV_POS.indexOf(pos) < 0) return; ls('mt_nav_pos2', pos); applyNav(pos); };

  if (!$('fx-nav-style')) {
    var st = document.createElement('style');
    st.id = 'fx-nav-style';
    st.textContent =
      '.bottom-nav{touch-action:none;-webkit-touch-callout:none;-webkit-user-select:none;user-select:none}' +
      '.bottom-nav.fx-held{transform-origin:center;filter:drop-shadow(0 8px 18px rgba(0,0,0,.25));opacity:.92}' +
      '#fx-zones{position:fixed;inset:0;z-index:9990;pointer-events:none;display:none}' +
      '#fx-zones.on{display:block}' +
      '#fx-zones .z{position:absolute;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:13px;color:var(--primary-hover,#4a9fd0);background:rgba(156,213,244,.18);border:2px dashed rgba(156,213,244,.7);transition:background .12s}' +
      '#fx-zones .z.hot{background:rgba(156,213,244,.55);color:#fff}' +
      '#fx-zones .z[data-pos="top"]{left:0;right:0;top:0;height:64px}' +
      '#fx-zones .z[data-pos="bottom"]{left:0;right:0;bottom:0;height:64px}' +
      '#fx-zones .z[data-pos="left"]{left:0;top:72px;bottom:72px;width:56px}' +
      '#fx-zones .z[data-pos="right"]{right:0;top:72px;bottom:72px;width:56px}' +
      '#fx-zones .tip{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);background:rgba(44,62,80,.85);color:#fff;font-size:13px;font-weight:700;padding:10px 16px;border-radius:14px;text-align:center;max-width:70%}' +
      '#fx-pop{position:fixed;inset:0;z-index:9995;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.4);padding:20px}' +
      '#fx-pop.on{display:flex}' +
      '#fx-pop .box{background:var(--card-bg,#fff);color:var(--text,#2c3e50);border-radius:24px;padding:18px;width:100%;max-width:340px;box-shadow:0 12px 40px rgba(0,0,0,.25)}' +
      '#fx-pop h3{margin:0 0 4px;font-size:16px;font-weight:800;text-align:center}' +
      '#fx-pop p{margin:0 0 14px;font-size:12px;color:var(--text-light,#7f8c8d);text-align:center}' +
      '#fx-pop .grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}' +
      '#fx-pop .fx-pop-opt{border:2px solid var(--primary-light,#cfe9f9);border-radius:18px;padding:10px 6px 8px;text-align:center;cursor:pointer;font-weight:700;font-size:13px;background:transparent;color:inherit;font-family:inherit}' +
      '#fx-pop .fx-pop-opt.active{border-color:var(--primary-hover,#4a9fd0);background:var(--primary-light,#cfe9f9)}' +
      '#fx-pop .ph{position:relative;width:46px;height:72px;margin:0 auto 6px;border:2px solid var(--text-light,#95a5a6);border-radius:10px;background:#fff;overflow:hidden}' +
      '#fx-pop .ph i{position:absolute;background:var(--primary-hover,#4a9fd0);border-radius:3px}' +
      '#fx-pop .ph[data-pos="top"] i{left:3px;right:3px;top:3px;height:9px}' +
      '#fx-pop .ph[data-pos="bottom"] i{left:3px;right:3px;bottom:3px;height:9px}' +
      '#fx-pop .ph[data-pos="left"] i{left:3px;top:14px;bottom:14px;width:9px}' +
      '#fx-pop .ph[data-pos="right"] i{right:3px;top:14px;bottom:14px;width:9px}' +
      '#fx-pop .close{display:block;margin:14px auto 0;border:0;background:transparent;color:var(--text-light,#7f8c8d);font-weight:700;font-size:13px;padding:6px 14px;font-family:inherit}';
    document.head.appendChild(st);
  }

  function ensureOverlays() {
    if (!$('fx-zones')) {
      var z = document.createElement('div');
      z.id = 'fx-zones';
      z.innerHTML = NAV_POS.map(function (p) { return '<div class="z" data-pos="' + p + '">' + NAV_LABEL[p] + '</div>'; }).join('') +
        '<div class="tip">ลากไปที่ขอบจอที่ต้องการ แล้วปล่อยนิ้ว</div>';
      document.body.appendChild(z);
    }
    if (!$('fx-pop')) {
      var p = document.createElement('div');
      p.id = 'fx-pop';
      p.innerHTML = '<div class="box"><h3>ย้ายแถบเมนู</h3><p>เลือกตำแหน่งที่ต้องการ (หรือกดแถบเมนูค้างแล้วลากไปขอบจอ)</p><div class="grid">' +
        NAV_POS.map(function (k) {
          return '<button type="button" class="fx-pop-opt" data-pos="' + k + '"><div class="ph" data-pos="' + k + '"><i></i></div>' + NAV_LABEL[k] + '</button>';
        }).join('') + '</div><button type="button" class="close">ปิด</button></div>';
      document.body.appendChild(p);
      p.addEventListener('click', function (e) {
        var o = e.target.closest && e.target.closest('.fx-pop-opt');
        if (o) { window.fxSetNav(o.getAttribute('data-pos')); window.fxCloseNavPopup(); return; }
        if (e.target === p || (e.target.classList && e.target.classList.contains('close'))) window.fxCloseNavPopup();
      });
    }
  }
  window.fxOpenNavPopup = function () { ensureOverlays(); applyNav(navPos()); $('fx-pop').classList.add('on'); };
  window.fxCloseNavPopup = function () { var p = $('fx-pop'); if (p) p.classList.remove('on'); };

  function nearestEdge(x, y) {
    var W = window.innerWidth, H = window.innerHeight;
    var d = { left: x, right: W - x, top: y, bottom: H - y }, best = 'top';
    NAV_POS.forEach(function (k) { if (d[k] < d[best]) best = k; });
    return best;
  }

  (function setupHold() {
    var timer = null, held = false, nav = null, sx = 0, sy = 0, moved = false, target = null, pid = null;
    var HOLD_MS = 450, CANCEL_PX = 10, DRAG_PX = 40;

    function reset() {
      clearTimeout(timer); timer = null;
      if (nav) {
        nav.classList.remove('fx-held');
        try { if (pid !== null) nav.releasePointerCapture(pid); } catch (e) {}
      }
      var z = $('fx-zones'); if (z) z.classList.remove('on');
      held = false; moved = false; nav = null; pid = null; target = null;
    }
    function markZone(edge) {
      document.querySelectorAll('#fx-zones .z').forEach(function (el) {
        el.classList.toggle('hot', el.getAttribute('data-pos') === edge);
      });
    }

    document.addEventListener('pointerdown', function (e) {
      var n = e.target.closest && e.target.closest('.bottom-nav');
      if (!n || (e.pointerType === 'mouse' && e.button !== 0)) return;
      reset();
      nav = n; sx = e.clientX; sy = e.clientY; pid = e.pointerId;
      timer = setTimeout(function () {
        held = true;
        try { nav.setPointerCapture(pid); } catch (err) {}
        try { if (navigator.vibrate) navigator.vibrate(18); } catch (err) {}
        ensureOverlays();
        nav.classList.add('fx-held');
        markZone(null);
        $('fx-zones').classList.add('on');
      }, HOLD_MS);
    }, true);

    document.addEventListener('pointermove', function (e) {
      if (!nav || e.pointerId !== pid) return;
      var dx = e.clientX - sx, dy = e.clientY - sy, dist = Math.sqrt(dx * dx + dy * dy);
      if (!held) { if (dist > CANCEL_PX) reset(); return; }
      moved = dist > DRAG_PX;
      target = moved ? nearestEdge(e.clientX, e.clientY) : null;
      markZone(target);
      e.preventDefault();
    }, true);

    function end(e) {
      if (!nav || e.pointerId !== pid) return;
      var wasHeld = held, wasMoved = moved, edge = target, cancelled = e.type === 'pointercancel';
      reset();
      if (!wasHeld) return;
      // กันไม่ให้การปล่อยนิ้วไปกดปุ่มเมนูโดยไม่ตั้งใจ
      var block = function (ev) { ev.stopPropagation(); ev.preventDefault(); };
      document.addEventListener('click', block, true);
      setTimeout(function () { document.removeEventListener('click', block, true); }, 350);
      if (wasMoved && edge && !cancelled) window.fxSetNav(edge); else window.fxOpenNavPopup();
    }
    document.addEventListener('pointerup', end, true);
    document.addEventListener('pointercancel', end, true);
    document.addEventListener('contextmenu', function (e) {
      if (e.target.closest && e.target.closest('.bottom-nav')) e.preventDefault();
    }, true);
  })();

  var themeGrid = document.querySelector('#view-me .theme-selector-grid');
  if (themeGrid && !$('fx-nav-card')) {
    var opt = function (pos, icon, label) {
      return '<div class="theme-option nav-pos-option" data-pos="' + pos + '" onclick="fxSetNav(\'' + pos + '\')">' +
        '<i class="fa-solid ' + icon + '" style="font-size:16px;color:var(--primary-hover)"></i><span>' + label + '</span></div>';
    };
    themeGrid.closest('.card').insertAdjacentHTML('afterend',
      '<div class="card" id="fx-nav-card">' +
      '<h3 style="font-size:14px;font-weight:800;margin-bottom:6px;display:flex;align-items:center;gap:8px">' +
      '<i class="fa-solid fa-up-down-left-right" style="color:var(--primary-hover)"></i><span>ตำแหน่งแถบเมนู</span></h3>' +
      '<p style="font-size:11px;color:var(--text-light);margin:0 0 10px">เคล็ดลับ: กดแถบเมนูค้างไว้ แล้วลากไปขอบจอที่ต้องการ หรือปล่อยเพื่อเปิดป๊อปอัป</p>' +
      '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:8px">' +
      opt('top', 'fa-arrow-up', 'บน') + opt('bottom', 'fa-arrow-down', 'ล่าง') +
      opt('left', 'fa-arrow-left', 'ซ้าย') + opt('right', 'fa-arrow-right', 'ขวา') +
      '</div></div>');
  }
  // ปุ่มดินสอ: แตะแล้วเปิดป๊อปอัปเลือกตำแหน่งแถบเมนู (บน/ล่าง/ซ้าย/ขวา)
  (function addPencil() {
    if ($('fx-edit')) return;
    var css = document.createElement('style');
    css.textContent =
      '#fx-edit{position:fixed;z-index:90;width:34px;height:34px;padding:0;border-radius:50%;border:2px solid var(--primary-light,#cfe9f9);background:#fff;color:var(--primary-hover,#4a9fd0);box-shadow:0 3px 10px rgba(0,0,0,.18);display:flex;align-items:center;justify-content:center;opacity:.88;-webkit-tap-highlight-color:transparent}' +
      '#fx-edit svg{width:16px;height:16px;fill:currentColor}' +
      'html[data-nav="top"] #fx-edit{top:calc(env(safe-area-inset-top,0px) + 70px);right:max(10px,calc(50% - 230px))}' +
      'html[data-nav="bottom"] #fx-edit{bottom:calc(env(safe-area-inset-bottom,0px) + 92px);left:max(10px,calc(50% - 230px))}' +
      'html[data-nav="left"] #fx-edit{top:calc(env(safe-area-inset-top,0px) + 10px);left:calc(max(6px,calc(50% - 234px)) + 12px)}' +
      'html[data-nav="right"] #fx-edit{top:calc(env(safe-area-inset-top,0px) + 10px);right:calc(max(6px,calc(50% - 234px)) + 12px)}';
    document.head.appendChild(css);
    var b = document.createElement('button');
    b.id = 'fx-edit'; b.type = 'button'; b.setAttribute('aria-label', 'ย้ายแถบเมนู');
    b.innerHTML = '<svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.8 9.94l-3.75-3.75L3 17.25zm17.7-10.2a1 1 0 0 0 0-1.4l-2.34-2.34a1 1 0 0 0-1.4 0l-1.83 1.83 3.75 3.75 1.82-1.84z"/></svg>';
    b.addEventListener('click', function (e) { e.stopPropagation(); window.fxOpenNavPopup(); });
    document.body.appendChild(b);
  })();
  applyNav(navPos());

  /* ---------- 1) โหลดเร็ว ---------- */
  var origFetch = window.fetchMonthData, first = true, noInit = false;
  (function () { var t = parseInt(ls('mt_noinit') || '0', 10); if (t && Date.now() - t < 12 * 3600 * 1000) noInit = true; })();

  function store(m, r, txs) {
    appState.profile = r.profile; appState.accounts = r.accounts; appState.categories = r.categories;
    appState.budget = r.budget; appState.summary = r.summary;
    appState.recentSpending = r.recentSpending; appState.recentIncome = r.recentIncome || [];
    appState.transactions = txs || [];
    appState.monthCache[m] = { dashboard: r, transactions: txs || [] };
  }

  // เรียกเซิร์ฟเวอร์ 1 ครั้ง (getInitData) แทน 2 ครั้ง; ถ้าเซิร์ฟเวอร์ยังไม่มีฟังก์ชันนี้ ถอยไปใช้แบบเดิม
  function fresh(m, done) {
    if (noInit) { origFetch(m, done); return; }
    google.script.run
      .withSuccessHandler(function (res) {
        store(m, res.dash, res.txs);
        ls('mt_snap_' + m, JSON.stringify(res)); ls('mt_snap_ts_' + m, String(Date.now()));
        if (done) done(res.dash);
      })
      .withFailureHandler(function (er) {
        noInit = true;
        if (/getInitData|is not a function|not found|ไม่พบ|undefined/i.test((er && er.message) || '')) ls('mt_noinit', String(Date.now()));
        origFetch(m, done);
      })
      .getInitData(m);
  }

  // เปิดครั้งแรก: แสดงข้อมูลที่จำไว้จากครั้งก่อนทันที แล้วค่อยอัปเดตเป็นข้อมูลล่าสุดเบื้องหลัง
  window.fetchMonthData = function (m, cb) {
    var snap = null;
    if (first) {
      first = false;
      var s = ls('mt_snap_' + m);
      if (s) { try { snap = JSON.parse(s); } catch (e) {} }
    }
    if (snap && snap.dash) {
      store(m, snap.dash, snap.txs);
      if (cb) cb(snap.dash);
      // รีโหลดซ้ำภายใน 20 วินาที: ใช้ข้อมูลที่เพิ่งจำไว้เลย ไม่ต้องรบกวนเซิร์ฟเวอร์ (ทุกการบันทึกของเราเองอัปเดตข้อมูลที่จำไว้อยู่แล้ว)
      if (Date.now() - parseInt(ls('mt_snap_ts_' + m) || '0', 10) < 20000) { renderTotal(); return; }
      fresh(m, function () {
        if (appState.selectedMonth === m) applyCachedMonth(m);
        renderTotal();
      });
    } else {
      fresh(m, cb);
    }
  };

  // โหลดเดือนข้างเคียงทีหลัง ไม่แย่งความเร็วตอนเปิดแอป
  var origPre = window.preloadAdjacentMonths;
  window.preloadAdjacentMonths = function (m) {
    clearTimeout(window.__mtPre);
    window.__mtPre = setTimeout(function () { origPre(m); }, 6000);
  };

  /* ---------- 2) ยอดคงเหลือรวม เลือกบัญชีได้ ---------- */
  function excl() { try { return JSON.parse(ls('mt_total_excl') || '[]'); } catch (e) { return []; } }
  function picked() {
    var ex = excl();
    return (appState.accounts || []).filter(function (a) { return ex.indexOf(a.id) < 0; });
  }
  function renderTotal() {
    var v = $('fx-total-val'); if (!v) return;
    v.textContent = fmtMoney(picked().reduce(function (s, a) { return s + (a.balance || 0); }, 0));
    $('fx-total-n').textContent = 'รวม ' + picked().length + ' จาก ' + (appState.accounts || []).length + ' บัญชี · แตะเพื่อเลือก/แก้ไข';
  }

  var anchor = $('dashboard-balance-val');
  if (anchor && !$('fx-total-wrap')) {
    anchor.closest('.summary-grid').insertAdjacentHTML('afterend',
      '<div class="summary-grid" id="fx-total-wrap"><div class="summary-card balance" style="cursor:pointer" onclick="fxOpenBalances()">' +
      '<div class="label"><i class="fa-solid fa-sack-dollar" style="color:var(--primary-hover)"></i><span>ยอดเงินคงเหลือรวม</span>' +
      '<i class="fa-solid fa-pen" style="margin-left:auto;color:var(--text-light)"></i></div>' +
      '<div id="fx-total-val" class="amount">₭0</div>' +
      '<div id="fx-total-n" style="font-size:11px;color:var(--text-light);font-weight:600"></div></div></div>');
  }

  var origDash = window.updateDashboardUI;
  window.updateDashboardUI = function () { origDash(); renderTotal(); };

  function sumRows() {
    var s = 0;
    document.querySelectorAll('.fx-bal-in').forEach(function (i) {
      var c = document.querySelector('.fx-bal-chk[data-id="' + i.getAttribute('data-id') + '"]');
      if (c && c.checked) s += parseFloat(i.value) || 0;
    });
    $('fx-bal-sum').textContent = fmtMoney(s);
  }
  window.fxSumRows = sumRows;

  window.fxOpenBalances = function () {
    if (!$('modal-balances')) {
      document.body.insertAdjacentHTML('beforeend',
        '<div id="modal-balances" class="modal-backdrop" onclick="closeModalOnBackdrop(event,\'modal-balances\')"><div class="modal-content">' +
        '<div class="modal-header"><span class="modal-title">เลือกบัญชีที่รวมยอด</span><button class="close-modal-btn" onclick="closeModal(\'modal-balances\')">✕</button></div>' +
        '<p style="font-size:12px;color:var(--text-light);margin-bottom:12px">ติ๊กบัญชีที่ต้องการนับรวม และแก้ยอดของแต่ละบัญชีได้</p>' +
        '<div id="fx-bal-list"></div>' +
        '<div style="display:flex;justify-content:space-between;font-weight:800;margin:14px 0 4px"><span>รวมบัญชีที่เลือก</span><span id="fx-bal-sum"></span></div>' +
        '<button class="btn-submit" onclick="fxSaveBalances()"><i class="fa-solid fa-floppy-disk"></i> บันทึก</button></div></div>');
    }
    var ex = excl(), box = $('fx-bal-list');
    if (!(appState.accounts || []).length) {
      box.innerHTML = '<p style="text-align:center;color:var(--text-light);font-size:13px">ยังไม่มีบัญชี ไปเพิ่มที่ ตั้งค่า → บัญชี</p>';
    } else {
      box.innerHTML = appState.accounts.map(function (a) {
        return '<div class="form-group"><label class="form-label" style="display:flex;align-items:center;gap:8px">' +
          '<input type="checkbox" class="fx-bal-chk" data-id="' + a.id + '"' + (ex.indexOf(a.id) < 0 ? ' checked' : '') + ' onchange="fxSumRows()"> ' +
          String(a.name).replace(/</g, '&lt;') + '</label>' +
          '<input type="number" step="any" class="input-field fx-bal-in" data-id="' + a.id + '" value="' + a.balance + '" oninput="fxSumRows()"></div>';
      }).join('');
    }
    sumRows();
    openModal('modal-balances');
  };

  window.fxSaveBalances = function () {
    var ex = [];
    document.querySelectorAll('.fx-bal-chk').forEach(function (c) { if (!c.checked) ex.push(c.getAttribute('data-id')); });
    ls('mt_total_excl', JSON.stringify(ex));
    var todo = [];
    document.querySelectorAll('.fx-bal-in').forEach(function (i) {
      var a = appState.accounts.filter(function (x) { return x.id === i.getAttribute('data-id'); })[0];
      var v = parseFloat(i.value) || 0;
      if (a && v !== a.balance) todo.push({ a: a, v: v });
    });
    if (!todo.length) { closeModal('modal-balances'); renderTotal(); return; }
    showLoading('กำลังบันทึกยอดคงเหลือ...');
    (function next(i, last) {
      if (i >= todo.length) {
        if (last) appState.accounts = last;
        appState.monthCache = {};
        ls('mt_snap_' + appState.selectedMonth, '');
        closeModal('modal-balances'); closeLoading(); updateDashboardUI();
        showSuccess('บันทึกแล้ว');
        return;
      }
      var t = todo[i];
      google.script.run
        .withSuccessHandler(function (accs) { next(i + 1, accs); })
        .withFailureHandler(function (er) { closeLoading(); showError(er.message); })
        .editAccount(t.a.id, { name: t.a.name, type: t.a.type, balance: t.v });
    })(0, null);
  };

  /* ---------- 3) สินค้าขายดีประจำเดือน (ไม่นับเงินเดือน) ---------- */
  function escH(t) { return String(t == null ? '' : t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  function isSalary(c) { return !c || c.icon === 'salary' || /เงินเดือน/.test(c.name || ''); }
  function isOtherName(n) { return /^(อื่นๆ|อื่น|ອື່ນໆ|ອື່ນ)+$/.test(String(n || '').replace(/\s+/g, '')); }
  function isOtherCat(c) { return !!c && isOtherName(c.name); }

  function renderBest() {
    var isInc = appState.chartsType === 'Income';
    var card = $('fx-best-card');
    if (!card) {
      var anchorEl = $('charts-category-progress-container');
      var host = anchorEl && anchorEl.closest('.card');
      if (!host) return;
      host.insertAdjacentHTML('afterend',
        '<div class="card" id="fx-best-card" style="display:none">' +
        '<h3 style="font-size:14px;font-weight:800;margin-bottom:12px;display:flex;align-items:center;gap:8px">' +
        '<i class="fa-solid fa-trophy" style="color:#f4b942"></i><span id="fx-best-title">สินค้าขายดีประจำเดือน</span></h3>' +
        '<div id="fx-best-list"></div></div>');
      card = $('fx-best-card');
    }
    var old = $('fx-prod-card'); if (old) old.style.display = 'none';
    card.style.display = isInc ? 'block' : 'none';
    if (!isInc) return;

    $('fx-best-title').textContent = 'สินค้าขายดีประจำเดือน (' + formatThaiMonth(appState.selectedMonth) + ')';
    var by = {};
    (appState.transactions || []).forEach(function (t) {
      if (t.type !== 'Income') return;
      var c = getCategoryById(t.categoryId);
      if (isSalary(c) || isOtherCat(c)) return;
      var o = by[t.categoryId] || (by[t.categoryId] = { id: t.categoryId, c: c, qty: 0, amt: 0 });
      o.qty += t.quantity || 0;
      o.amt += t.amount || 0;
    });
    var list = Object.keys(by).map(function (k) { return by[k]; }).sort(function (a, b) {
      return (b.qty - a.qty) || (b.amt - a.amt);
    }).slice(0, 10);

    var box = $('fx-best-list');
    if (!list.length) {
      box.innerHTML = '<p style="text-align:center;color:var(--text-light);font-size:13px">ยังไม่มีรายการขายสินค้าในเดือนนี้ (ไม่นับเงินเดือนและหมวดอื่นๆ)</p>';
      return;
    }
    var medal = ['#f4b942', '#b8c2cc', '#d99a6c'];
    box.innerHTML = list.map(function (e, i) {
      var c = e.c;
      return '<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">' +
        '<div style="width:26px;height:26px;border-radius:50%;background:' + (medal[i] || 'var(--primary-light)') + ';color:' + (i < 3 ? '#fff' : 'var(--text-light)') +
        ';font-size:12px;font-weight:800;display:flex;align-items:center;justify-content:center;flex-shrink:0">' + (i + 1) + '</div>' +
        '<div style="background:' + c.color + ';width:34px;height:34px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0">' +
        renderCategoryIcon(c.icon, 'var(--text)', '16px') + '</div>' +
        '<div style="flex:1;min-width:0"><div style="font-size:13px;font-weight:700">' + escH(c.name) + '</div>' +
        '<div style="font-size:11px;color:var(--text-light)">' + (e.qty > 0 ? 'ขายได้ ' + Number(e.qty).toLocaleString('en-US', { maximumFractionDigits: 2 }) + ' ชิ้น' : 'ไม่ได้ระบุจำนวน') + '</div></div>' +
        '<div style="font-weight:800;font-size:13px;color:var(--income-hover)">' + fmtMoney(e.amt) + '</div></div>';
    }).join('');
  }

  var _ucx = window.updateChartsUI;
  if (typeof _ucx === 'function') {
    window.updateChartsUI = function () { _ucx(); try { renderBest(); } catch (e) { console.error(e); } };
  }

  /* ---------- 4) หมวด "อื่นๆ" ไม่ต้องกรอกจำนวนสินค้า และไม่รวมในสถิติสินค้าขายดี ---------- */
  function updateQty() {
    var qg = $('qe-qty-group');
    if (qg) {
      var qSel = $('qe-category');
      var qShow = quickEntryType === 'Income' && !(qSel && isOtherCat(getCategoryById(qSel.value)));
      qg.style.display = qShow ? 'block' : 'none';
      if (!qShow && $('qe-qty')) $('qe-qty').value = '';
    }
    var tg = $('tx-qty-group');
    if (tg) {
      var tShow = appState.currentTxType === 'Income' && !isOtherCat(getCategoryById(appState.selectedCategoryId));
      tg.style.display = tShow ? 'block' : 'none';
      if (!tShow && $('tx-qty')) $('tx-qty').value = '';
    }
  }
  function wrapQty(name) {
    var f = window[name];
    if (typeof f !== 'function') return;
    window[name] = function () { var r = f.apply(this, arguments); try { updateQty(); } catch (e) {} return r; };
  }
  ['openQuickEntry', 'setTxType', 'populateCategoryPicker', 'openAddTransactionModal', 'openEditTransactionModal'].forEach(wrapQty);

  document.addEventListener('change', function (e) {
    if (e.target && e.target.id === 'qe-category') updateQty();
  });
  document.addEventListener('click', function (e) {
    if (e.target && e.target.closest && e.target.closest('#tx-category-picker')) setTimeout(updateQty, 0);
  });

  function filterYear() {
    var box = $('fx-year-products');
    if (!box) return;
    Array.prototype.slice.call(box.children).forEach(function (row) {
      var n = row.querySelector && row.querySelector('[style*="font-weight:700"]');
      if (n && isOtherName(n.textContent)) row.parentNode.removeChild(row);
    });
    if (!box.children.length) box.innerHTML = '<p style="text-align:center;color:var(--text-light);font-size:13px;">ยังไม่มีข้อมูล</p>';
  }
  var vc = $('view-charts');
  if (vc && window.MutationObserver) new MutationObserver(function () { filterYear(); }).observe(vc, { childList: true, subtree: true });


  /* ---------- 5) กด "ถัดไป" บนแป้นพิมพ์ เพื่อไปช่องต่อไป ----------
     จำนวนเงิน -> จำนวนสินค้า (ถ้ามี) -> ผู้จ่าย/ผู้รับเงิน -> โน้ต -> ปิดแป้นพิมพ์ (ข้ามช่องวันที่) */
  (function nextKey() {
    var CHAINS = [
      ['qe-amount', 'qe-qty', 'qe-party', 'qe-note'],
      ['tx-amount', 'tx-qty', 'tx-party', 'tx-note']
    ];
    var lastPtr = 0;
    ['pointerdown', 'touchstart', 'mousedown'].forEach(function (ev) {
      document.addEventListener(ev, function () { lastPtr = Date.now(); }, true);
    });
    function chainOf(id) { for (var i = 0; i < CHAINS.length; i++) { if (CHAINS[i].indexOf(id) >= 0) return CHAINS[i]; } return null; }
    function visible(el) { return !!el && !el.disabled && el.offsetParent !== null; }
    function focusAfter(id) {
      var ch = chainOf(id); if (!ch) return false;
      for (var i = ch.indexOf(id) + 1; i < ch.length; i++) {
        var el = $(ch[i]);
        if (visible(el)) { el.focus(); try { if (el.select && el.type !== 'number') el.select(); } catch (e) {} return true; }
      }
      var cur = $(id); if (cur && cur.blur) cur.blur();   // ช่องสุดท้าย: ปิดแป้นพิมพ์
      return true;
    }
    // ให้แป้นพิมพ์โชว์ปุ่ม "ถัดไป" / "เสร็จ"
    document.addEventListener('focusin', function (e) {
      var t = e.target, id = t && t.id, ch = id && chainOf(id);
      if (ch && t.setAttribute) t.setAttribute('enterkeyhint', ch.indexOf(id) === ch.length - 1 ? 'done' : 'next');
      // เบราว์เซอร์เด้งไปช่องวันที่เองหลังกด "ถัดไป" -> ข้ามไปช่องที่ควรเป็น
      if ((id === 'qe-date' || id === 'tx-date') && e.relatedTarget && Date.now() - lastPtr > 700) {
        var from = e.relatedTarget.id;
        if (from === 'qe-amount' || from === 'tx-amount') setTimeout(function () { focusAfter(from); }, 0);
      }
    }, true);
    document.addEventListener('keydown', function (e) {
      if (e.key !== 'Enter' && e.keyCode !== 13) return;
      var id = e.target && e.target.id;
      if (!chainOf(id) || e.target.tagName === 'TEXTAREA') return;
      e.preventDefault();
      focusAfter(id);
    }, true);
  })();

  renderTotal();
})();
