/* i18n.js - เปลี่ยนภาษาของระบบ: ไทย / ລາວ / English
   โหลดต่อท้าย features.js และ extras.js โดย index.html
   วิธีทำงาน: แปลข้อความบนหน้าจอจากพจนานุกรมด้านล่าง (ข้อความที่ไม่มีในพจนานุกรมจะแสดงเป็นภาษาไทยเหมือนเดิม)
   อยากเพิ่ม/แก้คำแปล: เพิ่มบรรทัดในรายการ D = [ไทย, English, ລາວ] */
(function () {
  'use strict';
  var LANGS = ['th', 'lo', 'en'];
  var NAMES = { th: 'ไทย', lo: 'ລາວ', en: 'English' };
  function $(id) { return document.getElementById(id); }
  function ls(k, v) { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) {} return null; }
  var lang = ls('mt_lang'); if (LANGS.indexOf(lang) < 0) lang = 'th';

  /* ---------- พจนานุกรม [ไทย, English, ລາວ] ---------- */
  var D = [
    // เมนู / หน้าหลัก
    ['หน้าหลัก', 'Home', 'ໜ້າຫຼັກ'], ['กราฟ', 'Charts', 'ກຣາຟ'], ['รายการ', 'Records', 'ລາຍການ'],
    ['ตั้งค่า', 'Settings', 'ຕັ້ງຄ່າ'], ['ข้อมูลฉัน', 'My Info', 'ຂໍ້ມູນຂອງຂ້ອຍ'], ['ประวัติ', 'History', 'ປະຫວັດ'],
    ['บัญชี', 'Accounts', 'ບັນຊີ'], ['งบประมาณ', 'Budget', 'ງົບປະມານ'], ['หมวดหมู่', 'Categories', 'ໝວດໝູ່'],
    ['รายรับ', 'Income', 'ລາຍຮັບ'], ['รายจ่าย', 'Expense', 'ລາຍຈ່າຍ'],
    ['รายรับรวม', 'Total income', 'ລາຍຮັບລວມ'], ['รายจ่ายรวม', 'Total expense', 'ລາຍຈ່າຍລວມ'],
    ['คงเหลือ', 'Balance', 'ຍັງເຫຼືອ'], ['ยอดคงเหลือ', 'Balance', 'ຍອດເຫຼືອ'],
    ['ยอดเงินคงเหลือรวม', 'Total balance', 'ຍອດເງິນເຫຼືອລວມ'],
    ['เพิ่มรายการ', 'Add record', 'ເພີ່ມລາຍການ'], ['แก้ไข', 'Edit', 'ແກ້ໄຂ'], ['ลบ', 'Delete', 'ລຶບ'],
    ['ค้นหา', 'Search', 'ຄົ້ນຫາ'], ['ทั้งหมด', 'All', 'ທັງໝົດ'], ['วันนี้', 'Today', 'ມື້ນີ້'], ['เดือนนี้', 'This month', 'ເດືອນນີ້'],
    // ฟอร์ม
    ['วันที่', 'Date', 'ວັນທີ'], ['จำนวนเงิน', 'Amount', 'ຈຳນວນເງິນ'], ['โน้ต', 'Note', 'ໝາຍເຫດ'], ['หมายเหตุ', 'Note', 'ໝາຍເຫດ'],
    ['ผู้รับเงิน', 'Payee', 'ຜູ້ຮັບເງິນ'], ['ผู้จ่ายเงิน', 'Payer', 'ຜູ້ຈ່າຍເງິນ'],
    ['ผู้รับเงิน (เราจ่ายเงินให้ใคร)', 'Payee (who we paid)', 'ຜູ້ຮັບເງິນ (ເຮົາຈ່າຍເງິນໃຫ້ໃຜ)'],
    ['ผู้จ่ายเงิน (ใครจ่ายเงินให้เรา)', 'Payer (who paid us)', 'ຜູ້ຈ່າຍເງິນ (ໃຜຈ່າຍເງິນໃຫ້ເຮົາ)'],
    ['เช่น ชื่อร้านค้า', 'e.g. shop name', 'ເຊັ່ນ ຊື່ຮ້ານຄ້າ'], ['เช่น ชื่อลูกค้า', 'e.g. customer name', 'ເຊັ່ນ ຊື່ລູກຄ້າ'], ['เช่น 5', 'e.g. 5', 'ເຊັ່ນ 5'],
    ['จำนวนที่ขายได้ (ชิ้น/ก้อน)', 'Quantity sold (pcs)', 'ຈຳນວນທີ່ຂາຍໄດ້ (ຊິ້ນ/ກ້ອນ)'],
    ['บันทึก', 'Save', 'ບັນທຶກ'], ['ยกเลิก', 'Cancel', 'ຍົກເລີກ'], ['ปิด', 'Close', 'ປິດ'], ['ยืนยันลบ', 'Confirm delete', 'ຢືນຢັນລຶບ'],
    ['ยืนยันลบรายการ?', 'Delete this record?', 'ຢືນຢັນລຶບລາຍການ?'],
    ['คุณต้องการลบรายการธุรกรรมนี้ใช่หรือไม่?', 'Do you want to delete this transaction?', 'ທ່ານຕ້ອງການລຶບລາຍການທຸລະກຳນີ້ແມ່ນບໍ່?'],
    // ข้อความแจ้งเตือน
    ['บันทึกสำเร็จ!', 'Saved!', 'ບັນທຶກສຳເລັດ!'], ['แก้ไขรายการสำเร็จ!', 'Record updated!', 'ແກ້ໄຂລາຍການສຳເລັດ!'],
    ['เพิ่มรายการสำเร็จ!', 'Record added!', 'ເພີ່ມລາຍການສຳເລັດ!'], ['ลบรายการสำเร็จ', 'Record deleted', 'ລຶບລາຍການສຳເລັດ'],
    ['บันทึกแล้ว', 'Saved', 'ບັນທຶກແລ້ວ'], ['กำลังบันทึกยอดคงเหลือ...', 'Saving balances...', 'ກຳລັງບັນທຶກຍອດເຫຼືອ...'],
    ['กรุณากรอกจำนวนเงิน', 'Please enter an amount', 'ກະລຸນາປ້ອນຈຳນວນເງິນ'], ['กรุณาเลือกวันที่', 'Please choose a date', 'ກະລຸນາເລືອກວັນທີ'],
    ['กรุณากรอกข้อมูลจำนวนเงิน วันที่ และเลือกหมวดหมู่ให้ครบถ้วน', 'Please fill in amount, date and category', 'ກະລຸນາປ້ອນຈຳນວນເງິນ, ວັນທີ ແລະ ເລືອກໝວດໝູ່ໃຫ້ຄົບ'],
    ['ยังไม่มีหมวดหมู่ประเภทนี้ ไปเพิ่มได้ที่ ข้อมูลฉัน → จัดการหมวดหมู่', 'No categories of this type yet. Add them at My Info → Manage categories', 'ຍັງບໍ່ມີໝວດໝູ່ປະເພດນີ້ ໄປເພີ່ມໄດ້ທີ່ ຂໍ້ມູນຂອງຂ້ອຍ → ຈັດການໝວດໝູ່'],
    ['ยังไม่มีบัญชีการเงิน ไปเพิ่มได้ที่ ตั้งค่า → บัญชี', 'No accounts yet. Add one at Settings → Accounts', 'ຍັງບໍ່ມີບັນຊີການເງິນ ໄປເພີ່ມໄດ້ທີ່ ຕັ້ງຄ່າ → ບັນຊີ'],
    ['ยังไม่มีบัญชี ไปเพิ่มที่ ตั้งค่า → บัญชี', 'No accounts yet. Add one at Settings → Accounts', 'ຍັງບໍ່ມີບັນຊີ ໄປເພີ່ມທີ່ ຕັ້ງຄ່າ → ບັນຊີ'],
    ['กำลังโหลด...', 'Loading...', 'ກຳລັງໂຫຼດ...'], ['เกิดข้อผิดพลาด', 'An error occurred', 'ເກີດຂໍ້ຜິດພາດ'], ['ไม่ทราบสาเหตุ', 'Unknown reason', 'ບໍ່ຮູ້ສາເຫດ'],
    // กราฟ / รายงาน
    ['ยอดขายแยกตามสินค้า', 'Sales by product', 'ຍອດຂາຍແຍກຕາມສິນຄ້າ'], ['จำนวนที่ขายได้ต่อวัน', 'Quantity sold per day', 'ຈຳນວນທີ່ຂາຍໄດ້ຕໍ່ວັນ'],
    ['ยังไม่มีข้อมูลจำนวนสินค้าในเดือนนี้', 'No product quantity data this month', 'ຍັງບໍ່ມີຂໍ້ມູນຈຳນວນສິນຄ້າໃນເດືອນນີ້'],
    ['สรุปรายรับ-รายจ่ายรายปี', 'Yearly income & expense summary', 'ສະຫຼຸບລາຍຮັບ-ລາຍຈ່າຍລາຍປີ'],
    ['สินค้าขายดีประจำปี', 'Best sellers of the year', 'ສິນຄ້າຂາຍດີປະຈຳປີ'], ['สินค้าขายดีประจำเดือน', 'Best sellers of the month', 'ສິນຄ້າຂາຍດີປະຈຳເດືອນ'],
    ['ยังไม่มีข้อมูล', 'No data yet', 'ຍັງບໍ່ມີຂໍ້ມູນ'], ['ปี', 'Year', 'ປີ'],
    ['ยังไม่มีรายการขายสินค้าในเดือนนี้ (ไม่นับเงินเดือนและหมวดอื่นๆ)', 'No product sales this month (salary and "Other" excluded)', 'ຍັງບໍ່ມີລາຍການຂາຍສິນຄ້າໃນເດືອນນີ້ (ບໍ່ນັບເງິນເດືອນ ແລະ ໝວດອື່ນໆ)'],
    ['ไม่ได้ระบุจำนวน', 'Quantity not specified', 'ບໍ່ໄດ້ລະບຸຈຳນວນ'], ['รายงานตามชื่อผู้จ่าย / ผู้รับเงิน', 'Report by payer / payee', 'ລາຍງານຕາມຊື່ຜູ້ຈ່າຍ / ຜູ້ຮັບເງິນ'],
    ['รายวัน', 'Daily', 'ລາຍວັນ'], ['รายเดือน', 'Monthly', 'ລາຍເດືອນ'], ['รายปี', 'Yearly', 'ລາຍປີ'],
    ['ไม่มีรายการในช่วงนี้', 'No records in this period', 'ບໍ່ມີລາຍການໃນຊ່ວງນີ້'], ['ไม่ระบุชื่อ', 'Unnamed', 'ບໍ່ລະບຸຊື່'],
    ['โหลดไม่สำเร็จ:', 'Failed to load:', 'ໂຫຼດບໍ່ສຳເລັດ:'], ['เงินเดือน', 'Salary', 'ເງິນເດືອນ'], ['อื่นๆ', 'Other', 'ອື່ນໆ'], ['ชิ้น', 'pcs', 'ຊິ້ນ'],
    // ยอดรวมทุกบัญชี
    ['เลือกบัญชีที่รวมยอด', 'Choose accounts to include', 'ເລືອກບັນຊີທີ່ລວມຍອດ'],
    ['ติ๊กบัญชีที่ต้องการนับรวม และแก้ยอดของแต่ละบัญชีได้', 'Tick the accounts to include; you can also edit each balance', 'ຕິກບັນຊີທີ່ຕ້ອງການນັບລວມ ແລະ ແກ້ຍອດຂອງແຕ່ລະບັນຊີໄດ້'],
    ['รวมบัญชีที่เลือก', 'Total of selected accounts', 'ລວມບັນຊີທີ່ເລືອກ'],
    // แถบเมนู / ภาษา
    ['ตำแหน่งแถบเมนู', 'Menu bar position', 'ຕຳແໜ່ງແຖບເມນູ'], ['บน', 'Top', 'ເທິງ'], ['ล่าง', 'Bottom', 'ລຸ່ມ'], ['ซ้าย', 'Left', 'ຊ້າຍ'], ['ขวา', 'Right', 'ຂວາ'],
    ['ย้ายแถบเมนู', 'Move menu bar', 'ຍ້າຍແຖບເມນູ'],
    ['เลือกตำแหน่งที่ต้องการ (หรือกดแถบเมนูค้างแล้วลากไปขอบจอ)', 'Choose a position (or press and hold the menu bar and drag it to a screen edge)', 'ເລືອກຕຳແໜ່ງທີ່ຕ້ອງການ (ຫຼື ກົດແຖບເມນູຄ້າງແລ້ວລາກໄປຂອບຈໍ)'],
    ['ลากไปที่ขอบจอที่ต้องการ แล้วปล่อยนิ้ว', 'Drag to a screen edge, then release', 'ລາກໄປທີ່ຂອບຈໍທີ່ຕ້ອງການ ແລ້ວປ່ອຍນິ້ວ'],
    ['เคล็ดลับ: กดแถบเมนูค้างไว้ แล้วลากไปขอบจอที่ต้องการ หรือปล่อยเพื่อเปิดป๊อปอัป', 'Tip: press and hold the menu bar and drag it to a screen edge, or release to open the popup', 'ຄຳແນະນຳ: ກົດແຖບເມນູຄ້າງໄວ້ ແລ້ວລາກໄປຂອບຈໍທີ່ຕ້ອງການ ຫຼື ປ່ອຍເພື່ອເປີດປ໊ອບອັບ'],
    ['ภาษา', 'Language', 'ພາສາ'], ['คัดลอกข้อความที่ยังไม่ได้แปล', 'Copy untranslated text', 'ສຳເນົາຂໍ້ຄວາມທີ່ຍັງບໍ່ໄດ້ແປ'], ['เลือกภาษา', 'Choose language', 'ເລືອກພາສາ'],
    // ข้อความตอนเปิดแอป
    ['ลองใหม่', 'Retry', 'ລອງໃໝ່'], ['กำลังเปิดแอป…', 'Opening app…', 'ກຳລັງເປີດແອັບ…'],
    // หน้า ข้อมูลฉัน (จากภาพหน้าจอ)
    ['ม่วงลาเวนเดอร์', 'Lavender purple', 'ມ່ວງລາເວັນເດີ'], ['ส้มเหลือง', 'Yellow orange', 'ສີສົ້ມເຫຼືອງ'], ['ดาร์กโหมด', 'Dark mode', 'ໂໝດມືດ'],
    ['จัดการหมวดหมู่สินค้า', 'Manage product categories', 'ຈັດການໝວດໝູ່ສິນຄ້າ'], ['จัดการรายชื่อพนักงาน', 'Manage employees', 'ຈັດການລາຍຊື່ພະນັກງານ'],
    ['ส่งออกข้อมูลสำรอง (CSV)', 'Export backup data (CSV)', 'ສົ່ງອອກຂໍ້ມູນສຳຮອງ (CSV)'], ['สกุลเงินหลัก', 'Main currency', 'ສະກຸນເງິນຫຼັກ'],
    ['กีบ', 'Kip', 'ກີບ'],
    // ข้อความจาก Index.html / features.html / Code.gs
    ["ยินดีต้อนรับ", "Welcome", "ຍິນດີຕ້ອນຮັບ"],
    ["ผู้ใช้งาน", "User", "ຜູ້ໃຊ້ງານ"],
    ["งบประมาณทั้งหมด:", "Total budget:", "ງົບປະມານທັງໝົດ:"],
    ["คงเหลือ:", "Remaining:", "ຍັງເຫຼືອ:"],
    ["เพิ่มรายรับ", "Add income", "ເພີ່ມລາຍຮັບ"],
    ["เพิ่มรายจ่าย", "Add expense", "ເພີ່ມລາຍຈ່າຍ"],
    ["จำนวนเงิน (กีบ)", "Amount (Kip)", "ຈຳນວນເງິນ (ກີບ)"],
    ["โน้ต (ไม่บังคับ)", "Note (optional)", "ໝາຍເຫດ (ບໍ່ບັງຄັບ)"],
    ["เช่น ซื้อวัตถุดิบ", "e.g. bought ingredients", "ເຊັ່ນ ຊື້ວັດຖຸດິບ"],
    ["บันทึกรายรับ", "Save income", "ບັນທຶກລາຍຮັບ"],
    ["บันทึกรายจ่าย", "Save expense", "ບັນທຶກລາຍຈ່າຍ"],
    ["รายรับวันนี้", "Today's income", "ລາຍຮັບມື້ນີ້"],
    ["รายจ่ายวันนี้", "Today's expense", "ລາຍຈ່າຍມື້ນີ້"],
    ["รายรับเดือนนี้", "This month's income", "ລາຍຮັບເດືອນນີ້"],
    ["รายจ่ายเดือนนี้", "This month's expense", "ລາຍຈ່າຍເດືອນນີ້"],
    ["คงเหลือสุทธิเดือนนี้", "Net balance this month", "ຍັງເຫຼືອສຸດທິເດືອນນີ້"],
    ["สถิติรายรับ 7 วันล่าสุด", "Income, last 7 days", "ສະຖິຕິລາຍຮັບ 7 ວັນຜ່ານມາ"],
    ["สถิติรายจ่าย 7 วันล่าสุด", "Expenses, last 7 days", "ສະຖິຕິລາຍຈ່າຍ 7 ວັນຜ່ານມາ"],
    ["🔍 ค้นหาโน้ต/รายการ...", "🔍 Search notes/records...", "🔍 ຄົ້ນຫາໝາຍເຫດ/ລາຍການ..."],
    ["สัดส่วนรายจ่ายตามหมวดหมู่", "Expense share by category", "ສັດສ່ວນລາຍຈ່າຍຕາມໝວດໝູ່"],
    ["สัดส่วนรายรับตามหมวดหมู่", "Income share by category", "ສັດສ່ວນລາຍຮັບຕາມໝວດໝູ່"],
    ["รายจ่ายแยกตามหมวดหมู่", "Expenses by category", "ລາຍຈ່າຍແຍກຕາມໝວດໝູ່"],
    ["รายรับแยกตามหมวดหมู่", "Income by category", "ລາຍຮັບແຍກຕາມໝວດໝູ່"],
    ["วิเคราะห์", "Analysis", "ວິເຄາະ"],
    ["ตั้งงบประมาณ", "Set budget", "ຕັ້ງງົບປະມານ"],
    ["สรุปการใช้จ่ายประจำเดือน", "Monthly spending summary", "ສະຫຼຸບການໃຊ້ຈ່າຍປະຈຳເດືອນ"],
    ["รายรับทั้งหมด:", "Total income:", "ລາຍຮັບທັງໝົດ:"],
    ["รายจ่ายทั้งหมด:", "Total expense:", "ລາຍຈ່າຍທັງໝົດ:"],
    ["คงเหลือสุทธิ:", "Net balance:", "ຍັງເຫຼືອສຸດທິ:"],
    ["บัญชีการเงินของคุณ", "Your financial accounts", "ບັນຊີການເງິນຂອງທ່ານ"],
    ["เพิ่มบัญชี", "Add account", "ເພີ່ມບັນຊີ"],
    ["ตั้งงบประมาณรวมประจำเดือน (กีบ)", "Set total monthly budget (Kip)", "ຕັ້ງງົບປະມານລວມປະຈຳເດືອນ (ກີບ)"],
    ["บันทึกงบรวม", "Save total budget", "ບັນທຶກງົບລວມ"],
    ["ตั้งงบประมาณรายหมวดหมู่", "Set budget per category", "ຕັ້ງງົບປະມານລາຍໝວດໝູ່"],
    ["บันทึกงบประมาณหมวดหมู่", "Save category budgets", "ບັນທຶກງົບປະມານໝວດໝູ່"],
    ["ชื่อของคุณ", "Your name", "ຊື່ຂອງທ່ານ"],
    ["บันทึกชื่อ", "Save name", "ບັນທຶກຊື່"],
    ["เลือกธีมสีแอปพลิเคชัน", "Choose app color theme", "ເລືອກທີມສີຂອງແອັບ"],
    ["ฟ้าพาสเทล", "Pastel blue", "ຟ້າພາສເຕວ"],
    ["ชมพูพาสเทล", "Pastel pink", "ຊົມພູພາສເຕວ"],
    ["เขียวมินต์", "Mint green", "ຂຽວມິນ"],
    ["เพิ่มรายการธุรกรรม", "Add transaction", "ເພີ່ມລາຍການທຸລະກຳ"],
    ["แก้ไขรายการธุรกรรม", "Edit transaction", "ແກ້ໄຂລາຍການທຸລະກຳ"],
    ["เลือกหมวดหมู่", "Choose category", "ເລືອກໝວດໝູ່"],
    ["เลือกบัญชีการเงิน", "Choose account", "ເລືອກບັນຊີການເງິນ"],
    ["บันทึกโน้ตเพิ่มเติม", "Additional note", "ບັນທຶກໝາຍເຫດເພີ່ມເຕີມ"],
    ["เช่น ซื้อกาแฟสดหน้าปากซอย", "e.g. fresh coffee at the corner", "ເຊັ່ນ ຊື້ກາເຟສົດໜ້າປາກຊອຍ"],
    ["บันทึกรายการ", "Save record", "ບັນທຶກລາຍການ"],
    ["ลบรายการนี้", "Delete this record", "ລຶບລາຍການນີ້"],
    ["เพิ่มบัญชีการเงิน", "Add account", "ເພີ່ມບັນຊີການເງິນ"],
    ["แก้ไขบัญชีการเงิน", "Edit account", "ແກ້ໄຂບັນຊີການເງິນ"],
    ["ชื่อบัญชี", "Account name", "ຊື່ບັນຊີ"],
    ["เช่น KBank เงินออม", "e.g. KBank savings", "ເຊັ່ນ KBank ເງິນອອມ"],
    ["ประเภทบัญชี", "Account type", "ປະເພດບັນຊີ"],
    ["เงินสด", "Cash", "ເງິນສົດ"],
    ["บัญชีธนาคาร", "Bank account", "ບັນຊີທະນາຄານ"],
    ["บัตรเครดิต", "Credit card", "ບັດເຄຣດິດ"],
    ["การลงทุน", "Investment", "ການລົງທຶນ"],
    ["ยอดเริ่มต้น (กีบ)", "Opening balance (Kip)", "ຍອດເລີ່ມຕົ້ນ (ກີບ)"],
    ["บันทึกบัญชี", "Save account", "ບັນທຶກບັນຊີ"],
    ["ลบบัญชีนี้", "Delete this account", "ລຶບບັນຊີນີ້"],
    ["จัดการหมวดหมู่", "Manage categories", "ຈັດການໝວດໝູ່"],
    ["➕ เพิ่มหมวดหมู่ใหม่", "➕ Add new category", "➕ ເພີ່ມໝວດໝູ່ໃໝ່"],
    ["ชื่อหมวดหมู่", "Category name", "ຊື່ໝວດໝູ່"],
    ["เช่น ค่าสติกเกอร์ไลน์", "e.g. LINE stickers", "ເຊັ່ນ ຄ່າສະຕິກເກີ LINE"],
    ["เลือกไอคอน (Icon Picker)", "Choose an icon", "ເລືອກໄອຄອນ"],
    ["เลือกสีพาสเทล", "Choose a pastel color", "ເລືອກສີພາສເຕວ"],
    ["บันทึกหมวดหมู่", "Save category", "ບັນທຶກໝວດໝູ່"],
    ["หมวดหมู่ทั้งหมด", "All categories", "ໝວດໝູ່ທັງໝົດ"],
    ["ลบ ✕", "Delete ✕", "ລຶບ ✕"],
    ["กำลังเริ่มต้นระบบ...", "Starting up...", "ກຳລັງເລີ່ມລະບົບ..."],
    ["กำลังเปลี่ยนเดือน...", "Changing month...", "ກຳລັງປ່ຽນເດືອນ..."],
    ["กำลังโหลดข้อมูล...", "Loading data...", "ກຳລັງໂຫຼດຂໍ້ມູນ..."],
    ["กำลังโหลดรายการ...", "Loading records...", "ກຳລັງໂຫຼດລາຍການ..."],
    ["กำลังโหลดกราฟ...", "Loading charts...", "ກຳລັງໂຫຼດກຣາຟ..."],
    ["กำลังโหลดข้อมูลรายงาน...", "Loading report data...", "ກຳລັງໂຫຼດຂໍ້ມູນລາຍງານ..."],
    ["ไม่พบรายการในเดือนนี้", "No records this month", "ບໍ່ພົບລາຍການໃນເດືອນນີ້"],
    ["หมวดหมู่ทั่วไป", "General", "ໝວດໝູ່ທົ່ວໄປ"],
    ["ไม่มีข้อมูลรายรับ", "No income data", "ບໍ່ມີຂໍ້ມູນລາຍຮັບ"],
    ["ไม่มีข้อมูลรายจ่าย", "No expense data", "ບໍ່ມີຂໍ້ມູນລາຍຈ່າຍ"],
    ["ไม่มีข้อมูล", "No data", "ບໍ່ມີຂໍ້ມູນ"],
    ["ไม่พบบัญชี", "No accounts found", "ບໍ່ພົບບັນຊີ"],
    ["กำลังบันทึกงบประมาณ...", "Saving budget...", "ກຳລັງບັນທຶກງົບປະມານ..."],
    ["บันทึกงบประมาณรวมสำเร็จ!", "Total budget saved!", "ບັນທຶກງົບປະມານລວມສຳເລັດ!"],
    ["กำลังบันทึกงบประมาณหมวดหมู่...", "Saving category budgets...", "ກຳລັງບັນທຶກງົບປະມານໝວດໝູ່..."],
    ["บันทึกงบประมาณหมวดหมู่สำเร็จ!", "Category budgets saved!", "ບັນທຶກງົບປະມານໝວດໝູ່ສຳເລັດ!"],
    ["กำลังเปลี่ยนชื่อ...", "Changing name...", "ກຳລັງປ່ຽນຊື່..."],
    ["บันทึกชื่อสำเร็จ!", "Name saved!", "ບັນທຶກຊື່ສຳເລັດ!"],
    ["กำลังอัปโหลดรูปภาพลง Google Drive...", "Uploading photo to Google Drive...", "ກຳລັງອັບໂຫຼດຮູບພາບລົງ Google Drive..."],
    ["อัปโหลดรูปภาพโปรไฟล์สำเร็จ!", "Profile photo uploaded!", "ອັບໂຫຼດຮູບໂປຣໄຟລ໌ສຳເລັດ!"],
    ["กำลังบันทึกรายการ...", "Saving record...", "ກຳລັງບັນທຶກລາຍການ..."],
    ["กำลังลบรายการ...", "Deleting record...", "ກຳລັງລຶບລາຍການ..."],
    ["กรุณากรอกชื่อบัญชี", "Please enter an account name", "ກະລຸນາປ້ອນຊື່ບັນຊີ"],
    ["กำลังบันทึกบัญชี...", "Saving account...", "ກຳລັງບັນທຶກບັນຊີ..."],
    ["บันทึกบัญชีสำเร็จ", "Account saved", "ບັນທຶກບັນຊີສຳເລັດ"],
    ["ยืนยันลบบัญชี?", "Delete this account?", "ຢືນຢັນລຶບບັນຊີ?"],
    ["คุณต้องการลบบัญชีการเงินนี้ใช่หรือไม่?", "Do you want to delete this account?", "ທ່ານຕ້ອງການລຶບບັນຊີການເງິນນີ້ແມ່ນບໍ່?"],
    ["ลบบัญชี", "Delete account", "ລຶບບັນຊີ"],
    ["กำลังลบบัญชี...", "Deleting account...", "ກຳລັງລຶບບັນຊີ..."],
    ["ลบบัญชีสำเร็จ", "Account deleted", "ລຶບບັນຊີສຳເລັດ"],
    ["กำลังเพิ่มหมวดหมู่...", "Adding category...", "ກຳລັງເພີ່ມໝວດໝູ່..."],
    ["เพิ่มหมวดหมู่สำเร็จ!", "Category added!", "ເພີ່ມໝວດໝູ່ສຳເລັດ!"],
    ["ยืนยันลบหมวดหมู่?", "Delete this category?", "ຢືນຢັນລຶບໝວດໝູ່?"],
    ["ต้องการลบหมวดหมู่นี้ใช่หรือไม่? รายการเก่าที่ใช้หมวดหมู่นี้จะยังอยู่ แต่จะแสดงเป็นหมวดหมู่ทั่วไป", "Delete this category? Old records using it will remain but be shown as General.", "ຕ້ອງການລຶບໝວດໝູ່ນີ້ແມ່ນບໍ່? ລາຍການເກົ່າທີ່ໃຊ້ໝວດໝູ່ນີ້ຈະຍັງຢູ່ ແຕ່ຈະສະແດງເປັນໝວດໝູ່ທົ່ວໄປ"],
    ["ยืนยัน", "Confirm", "ຢືນຢັນ"],
    ["กำลังลบหมวดหมู่...", "Deleting category...", "ກຳລັງລຶບໝວດໝູ່..."],
    ["ลบหมวดหมู่เรียบร้อยแล้ว", "Category deleted", "ລຶບໝວດໝູ່ຮຽບຮ້ອຍແລ້ວ"],
    ["กรุณากรอกชื่อหมวดหมู่", "Please enter a category name", "ກະລຸນາປ້ອນຊື່ໝວດໝູ່"],
    ["ไม่มีข้อมูลธุรกรรมที่จะส่งออก", "No transactions to export", "ບໍ່ມີຂໍ້ມູນທຸລະກຳທີ່ຈະສົ່ງອອກ"],
    ["กำลังสร้างไฟล์สำรองข้อมูล...", "Creating backup file...", "ກຳລັງສ້າງໄຟລ໌ສຳຮອງຂໍ້ມູນ..."],
    ["ดาวน์โหลดไฟล์สำรองข้อมูลสำเร็จ!", "Backup file downloaded!", "ດາວໂຫຼດໄຟລ໌ສຳຮອງຂໍ້ມູນສຳເລັດ!"],
    ["พนักงานผู้บันทึก", "Recorded by", "ພະນັກງານຜູ້ບັນທຶກ"],
    ["- ไม่ระบุ -", "- Not specified -", "- ບໍ່ລະບຸ -"],
    ["เพิ่มชื่อ", "Add name", "ເພີ່ມຊື່"],
    ["➕ เพิ่มชื่อใหม่", "➕ Add new name", "➕ ເພີ່ມຊື່ໃໝ່"],
    ["ชื่อ", "Name", "ຊື່"],
    ["เช่น สมชาย", "e.g. Somchai", "ເຊັ່ນ ສົມຊາຍ"],
    ["รายชื่อทั้งหมด", "All names", "ລາຍຊື່ທັງໝົດ"],
    ["ยังไม่มีรายชื่อ", "No names yet", "ຍັງບໍ່ມີລາຍຊື່"],
    ["กรุณากรอกชื่อ", "Please enter a name", "ກະລຸນາປ້ອນຊື່"],
    ["กำลังบันทึกชื่อ...", "Saving name...", "ກຳລັງບັນທຶກຊື່..."],
    ["เพิ่มชื่อสำเร็จ!", "Name added!", "ເພີ່ມຊື່ສຳເລັດ!"],
    ["ลบชื่อนี้?", "Delete this name?", "ລຶບຊື່ນີ້ບໍ?"],
    ["รายการเก่าที่เคยใช้ชื่อนี้จะยังแสดงชื่อเดิมอยู่", "Old records that used this name will still show it", "ລາຍການເກົ່າທີ່ເຄີຍໃຊ້ຊື່ນີ້ຍັງຈະສະແດງຊື່ເດີມຢູ່"],
    ["กำลังลบ...", "Deleting...", "ກຳລັງລຶບ..."],
    ["ลบเรียบร้อย", "Deleted", "ລຶບຮຽບຮ້ອຍ"],
    ["รายรับ-รายจ่ายรายวัน", "Daily income & expense", "ລາຍຮັບ-ລາຍຈ່າຍລາຍວັນ"],
    ["อาหาร", "Food", "ອາຫານ"],
    ["การเดินทาง", "Transport", "ການເດີນທາງ"],
    ["ช้อปปิ้ง", "Shopping", "ຊື້ເຄື່ອງ"],
    ["รถยนต์", "Car", "ລົດ"],
    ["ซ่อมบำรุง", "Repairs", "ສ້ອມແປງ"],
    ["ค่าโทรศัพท์", "Phone", "ຄ່າໂທລະສັບ"],
    ["ความบันเทิง", "Entertainment", "ຄວາມບັນເທີງ"],
    ["สุขภาพ", "Health", "ສຸຂະພາບ"],
    ["บิล/ค่าไฟ", "Bills/Electricity", "ບິນ/ຄ່າໄຟ"],
    ["ค่าเช่าบ้าน", "Rent", "ຄ່າເຊົ່າເຮືອນ"],
    ["การศึกษา", "Education", "ການສຶກສາ"],
    ["ท่องเที่ยว", "Travel", "ທ່ອງທ່ຽວ"],
    ["สัตว์เลี้ยง", "Pets", "ສັດລ້ຽງ"],
    ["ของขวัญ", "Gifts", "ຂອງຂວັນ"],
    ["เสื้อผ้า", "Clothing", "ເສື້ອຜ້າ"],
    ["ของชำ", "Groceries", "ເຄື່ອງໃຊ້ປະຈຳວັນ"],
    ["กาแฟ", "Coffee", "ກາເຟ"],
    ["โบนัส", "Bonus", "ໂບນັດ"],
    // เดือน (เต็ม/ย่อ)
    ['มกราคม', 'January', 'ມັງກອນ'], ['กุมภาพันธ์', 'February', 'ກຸມພາ'], ['มีนาคม', 'March', 'ມີນາ'], ['เมษายน', 'April', 'ເມສາ'],
    ['พฤษภาคม', 'May', 'ພຶດສະພາ'], ['มิถุนายน', 'June', 'ມິຖຸນາ'], ['กรกฎาคม', 'July', 'ກໍລະກົດ'], ['สิงหาคม', 'August', 'ສິງຫາ'],
    ['กันยายน', 'September', 'ກັນຍາ'], ['ตุลาคม', 'October', 'ຕຸລາ'], ['พฤศจิกายน', 'November', 'ພະຈິກ'], ['ธันวาคม', 'December', 'ທັນວາ'],
    ['ม.ค.', 'Jan', 'ມ.ກ.'], ['ก.พ.', 'Feb', 'ກ.ພ.'], ['มี.ค.', 'Mar', 'ມ.ນ.'], ['เม.ย.', 'Apr', 'ມ.ສ.'], ['พ.ค.', 'May', 'ພ.ພ.'], ['มิ.ย.', 'Jun', 'ມິ.ຖ.'],
    ['ก.ค.', 'Jul', 'ກ.ລ.'], ['ส.ค.', 'Aug', 'ສ.ຫ.'], ['ก.ย.', 'Sep', 'ກ.ຍ.'], ['ต.ค.', 'Oct', 'ຕ.ລ.'], ['พ.ย.', 'Nov', 'ພ.ຈ.'], ['ธ.ค.', 'Dec', 'ທ.ວ.']
  ];
  var EN = {}, LO = {}, MONTHS = {};
  D.forEach(function (r) { EN[r[0]] = r[1]; LO[r[0]] = r[2]; });
  MONTHS.th = ['มกราคม','กุมภาพันธ์','มีนาคม','เมษายน','พฤษภาคม','มิถุนายน','กรกฎาคม','สิงหาคม','กันยายน','ตุลาคม','พฤศจิกายน','ธันวาคม'];
  MONTHS.en = MONTHS.th.map(function (m) { return EN[m]; });
  MONTHS.lo = MONTHS.th.map(function (m) { return LO[m]; });

  /* ข้อความที่มีตัวเลข/ชื่อปนอยู่ [regex, English, ລາວ] (ใช้ $1 $2 แทนส่วนที่เปลี่ยนไป) */
  var RULES = [
    [/^ใช้ไป (.*)$/, 'Spent $1', 'ໃຊ້ໄປ $1'],
    [/^ปี (\d{4})$/, 'Year $1', 'ປີ $1'],
    [/^วันที่ (\d+)$/, 'Day $1', 'ວັນທີ $1'],
    [/ · โดย (.*)$/, ' · by $1', ' · ໂດຍ $1'],
    [/^อัปโหลดล้มเหลว: (.*)$/, 'Upload failed: $1', 'ອັບໂຫຼດບໍ່ສຳເລັດ: $1'],
    [/^รายรับ-รายจ่ายรายวัน \((.*)\)$/, 'Daily income & expense ($1)', 'ລາຍຮັບ-ລາຍຈ່າຍລາຍວັນ ($1)'],
    [/^บันทึกรายการ$/, 'Save record', 'ບັນທຶກລາຍການ'],
    [/^รวม (\d+) จาก (\d+) บัญชี · แตะเพื่อเลือก\/แก้ไข$/, 'Total of $1 of $2 accounts · tap to select/edit', 'ລວມ $1 ຈາກ $2 ບັນຊີ · ແຕະເພື່ອເລືອກ/ແກ້ໄຂ'],
    [/^ขายได้ ([\d,.]+) ชิ้น$/, 'Sold $1 pcs', 'ຂາຍໄດ້ $1 ຊິ້ນ'],
    [/ · ขาย ([\d,.]+) ชิ้น$/, ' · sold $1 pcs', ' · ຂາຍ $1 ຊິ້ນ'],
    [/^จาก /, 'From ', 'ຈາກ '], [/^ถึง /, 'To ', 'ເຖິງ '],
    [/^(\d+) รายการ$/, '$1 records', '$1 ລາຍການ'],
    [/^สินค้าขายดีประจำเดือน \((.*)\)$/, 'Best sellers of the month ($1)', 'ສິນຄ້າຂາຍດີປະຈຳເດືອນ ($1)'],
    [/^LAK ₭ \(กีบ\)$/, 'LAK ₭ (Kip)', 'LAK ₭ (ກີບ)'],
    [/^โหลดไม่สำเร็จ: (.*)$/, 'Failed to load: $1', 'ໂຫຼດບໍ່ສຳເລັດ: $1'],
    [/^บันทึกไม่สำเร็จ: (.*) \(กำลังโหลดข้อมูลจริงอีกครั้ง\)$/, 'Save failed: $1 (reloading real data)', 'ບັນທຶກບໍ່ສຳເລັດ: $1 (ກຳລັງໂຫຼດຂໍ້ມູນຈິງອີກຄັ້ງ)'],
    [/^เกิดข้อผิดพลาดในการโหลดข้อมูล: (.*)$/, 'Error loading data: $1', 'ເກີດຂໍ້ຜິດພາດໃນການໂຫຼດຂໍ້ມູນ: $1']
  ];

  function tr(s) {
    if (lang === 'th') return s;
    var map = lang === 'en' ? EN : LO, k = lang === 'en' ? 1 : 2;
    if (Object.prototype.hasOwnProperty.call(map, s)) return map[s];
    var my = /^(\S+) (\d{4})$/.exec(s);
    if (my && Object.prototype.hasOwnProperty.call(map, my[1])) return map[my[1]] + ' ' + my[2];
    var out = s;
    for (var i = 0; i < RULES.length; i++) out = out.replace(RULES[i][0], RULES[i][k]);
    return out;
  }
  window.mtT = function (th) { return tr(String(th)); };

  /* ---------- แปลข้อความบนหน้าจอ ---------- */
  var HAS_TH = /[\u0E00-\u0E7F]/, ATTRS = ['placeholder', 'title', 'aria-label'];
  function doText(n) {
    var v = n.nodeValue, orig;
    if (n.__t !== undefined && v === n.__t) orig = n.__o;
    else { orig = v; if (!HAS_TH.test(orig)) { n.__o = undefined; n.__t = undefined; return; } n.__o = orig; }
    var m = /^(\s*)([\s\S]*?)(\s*)$/.exec(orig);
    var out = m[2] ? m[1] + tr(m[2]) + m[3] : orig;
    n.__t = out;
    if (out !== v) n.nodeValue = out;
  }
  function doEl(el) {
    for (var i = 0; i < ATTRS.length; i++) {
      var a = ATTRS[i], v = el.getAttribute && el.getAttribute(a);
      if (v == null) continue;
      el.__oa = el.__oa || {}; el.__ta = el.__ta || {};
      var orig = (el.__ta[a] !== undefined && v === el.__ta[a]) ? el.__oa[a] : v;
      if (!HAS_TH.test(orig)) continue;
      el.__oa[a] = orig;
      var out = tr(orig); el.__ta[a] = out;
      if (out !== v) el.setAttribute(a, out);
    }
  }
  function walk(root) {
    if (!root) return;
    if (root.nodeType === 3) { doText(root); return; }
    if (root.nodeType !== 1) return;
    var tag = root.tagName;
    if (tag === 'SCRIPT' || tag === 'STYLE') return;
    doEl(root);
    var w = document.createTreeWalker(root, 5, null), n;
    while ((n = w.nextNode())) {
      if (n.nodeType === 3) { var p = n.parentNode && n.parentNode.tagName; if (p !== 'SCRIPT' && p !== 'STYLE') doText(n); }
      else doEl(n);
    }
  }

  var queue = [], raf = 0;
  function flush() {
    raf = 0; var q = queue; queue = [];
    for (var i = 0; i < q.length; i++) { try { if (q[i].isConnected !== false) walk(q[i]); } catch (e) {} }
  }
  function enqueue(n) { queue.push(n); if (!raf) raf = (window.requestAnimationFrame || setTimeout)(flush, 16); }

  var obs = new MutationObserver(function (muts) {
    if (lang === 'th' && !window.__mtTouched) return;
    for (var i = 0; i < muts.length; i++) {
      var m = muts[i];
      if (m.type === 'childList') { for (var j = 0; j < m.addedNodes.length; j++) enqueue(m.addedNodes[j]); }
      else if (m.type === 'characterData') enqueue(m.target);
      else if (m.type === 'attributes') enqueue(m.target);
    }
  });
  obs.observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });

  /* ชื่อเดือนตามภาษา (แทนฟังก์ชันเดิมที่เป็นภาษาไทยอย่างเดียว) */
  window.formatThaiMonth = function (monthStr) {
    var p = String(monthStr).split('-');
    return MONTHS[lang][parseInt(p[1], 10) - 1] + ' ' + parseInt(p[0], 10);
  };

  function setLang(l) {
    if (LANGS.indexOf(l) < 0) return;
    lang = l; ls('mt_lang', l); window.__mtTouched = true;
    document.documentElement.setAttribute('lang', l === 'th' ? 'th' : l === 'lo' ? 'lo' : 'en');
    walk(document.body);
    document.querySelectorAll('.fx-lang-opt').forEach(function (el) { el.classList.toggle('active', el.getAttribute('data-l') === l); });
    try { if (typeof window.updateDashboardUI === 'function') window.updateDashboardUI(); } catch (e) {}
    try { if (typeof window.updateChartsUI === 'function') window.updateChartsUI(); } catch (e) {}
    walk(document.body);
  }
  window.fxSetLang = setLang;

  /* รวบรวมข้อความที่ยังเป็นภาษาไทยอยู่บนหน้าจอ (ตอนเลือกภาษาอื่น) เพื่อส่งให้ผู้พัฒนาเพิ่มคำแปล */
  function untranslated() {
    var seen = {}, list = [];
    function add(t) { t = String(t || '').replace(/\s+/g, ' ').trim(); if (t && HAS_TH.test(t) && !seen[t]) { seen[t] = 1; list.push(t); } }
    var w = document.createTreeWalker(document.body, 5, null), n;
    while ((n = w.nextNode())) {
      if (n.nodeType === 3) { var p = n.parentNode && n.parentNode.tagName; if (p !== 'SCRIPT' && p !== 'STYLE') add(n.nodeValue); }
      else ATTRS.forEach(function (a) { if (n.getAttribute) add(n.getAttribute(a)); });
    }
    return list;
  }
  window.fxCopyUntranslated = function () {
    var list = untranslated();
    var txt = list.join('\n');
    var done = function () { alert(list.length ? ('คัดลอกแล้ว ' + list.length + ' ข้อความ ส่งให้ผู้พัฒนาได้เลย') : 'ไม่เหลือข้อความภาษาไทยที่ยังไม่แปลแล้ว'); };
    try { navigator.clipboard.writeText(txt).then(done, function () { fallback(); }); } catch (e) { fallback(); }
    function fallback() {
      var ta = document.createElement('textarea'); ta.value = txt; ta.style.cssText = 'position:fixed;left:0;top:0;width:90%;height:50%;z-index:99999';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      setTimeout(function () { document.body.removeChild(ta); }, 8000); done();
    }
  };

  /* ---------- หน้าต่างเลือกภาษา + ปุ่มลูกโลก + การ์ดในหน้า ตั้งค่า ---------- */
  var css = document.createElement('style');
  css.textContent =
    '#fx-lang-btn{position:fixed;z-index:90;width:34px;height:34px;padding:0;border-radius:50%;border:2px solid var(--primary-light,#cfe9f9);background:#fff;color:var(--primary-hover,#4a9fd0);box-shadow:0 3px 10px rgba(0,0,0,.18);display:flex;align-items:center;justify-content:center;opacity:.88;-webkit-tap-highlight-color:transparent}' +
    '#fx-lang-btn svg{width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2}' +
    'html[data-nav="top"] #fx-lang-btn{top:calc(env(safe-area-inset-top,0px) + 70px);right:calc(max(10px,calc(50% - 230px)) + 42px)}' +
    'html[data-nav="bottom"] #fx-lang-btn{bottom:calc(env(safe-area-inset-bottom,0px) + 92px);left:calc(max(10px,calc(50% - 230px)) + 42px)}' +
    'html[data-nav="left"] #fx-lang-btn{top:calc(env(safe-area-inset-top,0px) + 52px);left:calc(max(6px,calc(50% - 234px)) + 12px)}' +
    'html[data-nav="right"] #fx-lang-btn{top:calc(env(safe-area-inset-top,0px) + 52px);right:calc(max(6px,calc(50% - 234px)) + 12px)}' +
    '#fx-lang-pop{position:fixed;inset:0;z-index:9996;display:none;align-items:center;justify-content:center;background:rgba(0,0,0,.4);padding:20px}' +
    '#fx-lang-pop.on{display:flex}' +
    '#fx-lang-pop .box{background:var(--card-bg,#fff);color:var(--text,#2c3e50);border-radius:24px;padding:18px;width:100%;max-width:300px;box-shadow:0 12px 40px rgba(0,0,0,.25)}' +
    '#fx-lang-pop h3{margin:0 0 12px;font-size:16px;font-weight:800;text-align:center}' +
    '.fx-lang-opt{display:block;width:100%;margin-top:8px;padding:12px;border:2px solid var(--primary-light,#cfe9f9);border-radius:16px;background:transparent;color:inherit;font-weight:800;font-size:15px;font-family:inherit}' +
    '.fx-lang-opt.active{border-color:var(--primary-hover,#4a9fd0);background:var(--primary-light,#cfe9f9)}' +
    '#fx-lang-pop .close{display:block;margin:12px auto 0;border:0;background:transparent;color:var(--text-light,#7f8c8d);font-weight:700;font-size:13px;padding:6px 14px;font-family:inherit}';
  document.head.appendChild(css);

  function optsHtml() {
    return LANGS.map(function (l) { return '<button type="button" class="fx-lang-opt' + (l === lang ? ' active' : '') + '" data-l="' + l + '">' + NAMES[l] + '</button>'; }).join('');
  }
  window.fxOpenLangPopup = function () {
    var p = $('fx-lang-pop');
    if (!p) {
      p = document.createElement('div'); p.id = 'fx-lang-pop';
      p.innerHTML = '<div class="box"><h3>🌐 ภาษา / ພາສາ / Language</h3>' + optsHtml() + '<button type="button" class="close">✕</button></div>';
      document.body.appendChild(p);
      p.addEventListener('click', function (e) {
        var o = e.target.closest && e.target.closest('.fx-lang-opt');
        if (o) { setLang(o.getAttribute('data-l')); p.classList.remove('on'); return; }
        if (e.target === p || (e.target.classList && e.target.classList.contains('close'))) p.classList.remove('on');
      });
    }
    p.classList.add('on');
  };

  if (!$('fx-lang-btn')) {
    var b = document.createElement('button');
    b.id = 'fx-lang-btn'; b.type = 'button'; b.setAttribute('aria-label', 'Language');
    b.innerHTML = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18"/></svg>';
    b.addEventListener('click', function (e) { e.stopPropagation(); window.fxOpenLangPopup(); });
    document.body.appendChild(b);
  }

  var themeGrid = document.querySelector('#view-me .theme-selector-grid');
  if (themeGrid && !$('fx-lang-card')) {
    var after = $('fx-nav-card') || themeGrid.closest('.card');
    after.insertAdjacentHTML('afterend',
      '<div class="card" id="fx-lang-card"><h3 style="font-size:14px;font-weight:800;margin-bottom:10px">🌐 <span>ภาษา</span></h3>' +
      '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">' +
      LANGS.map(function (l) { return '<button type="button" class="fx-lang-opt' + (l === lang ? ' active' : '') + '" style="margin-top:0" data-l="' + l + '" onclick="fxSetLang(\'' + l + '\')">' + NAMES[l] + '</button>'; }).join('') +
      '</div><button type="button" onclick="fxCopyUntranslated()" style="margin-top:10px;border:0;background:transparent;color:var(--text-light,#7f8c8d);font-size:11px;font-weight:700;text-decoration:underline;font-family:inherit">คัดลอกข้อความที่ยังไม่ได้แปล</button></div>');
  }

  /* เริ่มต้น: ถ้าเลือกภาษาอื่นที่ไม่ใช่ไทยไว้ ให้แปลทันที */
  document.documentElement.setAttribute('lang', lang);
  if (lang !== 'th') { window.__mtTouched = true; walk(document.body); }
})();
